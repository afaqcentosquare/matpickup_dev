<div class="form-group">
	<label for="{{ $id }}">{{ $title }}</label>
	<textarea name="{{ $name }}" class="form-control {{ $class }}" cols="{{ $cols }}" rows="{{ $rows }}" id="{{ $id }}" >{!! $value !!}</textarea>
</div>