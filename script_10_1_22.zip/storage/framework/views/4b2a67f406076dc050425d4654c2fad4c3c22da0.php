
<?php $__env->startSection('content'); ?>
    <?php
    $currency = \App\Options::where('key', 'currency_name')
        ->select('value')
        ->first();
    ?>
    <div class="pjax-container">
        <!-- success-alert start -->
        <div class="alert-message-area">
            <div class="alert-content">
                <h4 class="ale"><?php echo e(__('Your Settings Successfully Updated')); ?></h4>
            </div>
        </div>
        <!-- success-alert end -->

        <!-- error-alert start -->
        <div class="error-message-area">
            <div class="error-content">
                <h4 class="error-msg"></h4>
            </div>
        </div>
        <nav class="breadcrumb-section section-py bg-light2">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="bread-crumb-title">Mitt Konto</h3>
                        
                    </div>
                </div>
            </div>
        </nav>

        <div class="my-account section-py">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="title text-capitalize mb-5 pb-4">Mitt Konto</h3>
                    </div>
                    <!-- My Account Tab Menu Start -->
                    <div class="col-lg-3 col-12 mb-5">
                        <div class="myaccount-tab-menu nav" role="tablist">
                            <a href="#dashboad" data-bs-toggle="tab" class="active"><i
                                    class="fa fa-tachometer"></i>Kontrollpanel</a>

                            <a href="#orders" data-bs-toggle="tab"><i class="fa fa-cart-arrow-down"></i>
                                <?php echo e(__('Orders')); ?></a>
                            <a href="#addresses" data-bs-toggle="tab"><i class="fa fa-cart-arrow-down"></i> Addresses</a>

                            <a href="#account-info" data-bs-toggle="tab"><i class="fa fa-user"></i>Inställningar</a>

                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                                data-bs-toggle="tab">
                                <i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                    <!-- My Account Tab Menu End -->

                    <!-- My Account Tab Content Start -->
                    <div class="col-lg-9 col-12 mb-5">
                        <div class="tab-content" id="myaccountContent">
                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade active show" id="dashboad" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Kontrollpanel</h3>

                                    <div class="welcome mb-20">
                                        <p>
                                            Hej, <strong><?php echo e(Auth::User()->name); ?></strong>
                                        </p>
                                    </div>

                                    <p class="mb-0">
                                        Från din kontos Kontrollpanel . du kan enkelt kontrollera och se dina senaste
                                        beställningar, hantera dina leverans- och faktureringsadresser och redigera ditt
                                        lösenord och kontouppgifter.
                                    </p>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->

                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade" id="orders" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Orders</h3>

                                    <div class="myaccount-table table-responsive text-center">
                                        <table class="table table-bordered">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>Beställnings-id</th>
                                                    <th>Betalnings Sätt</th>
                                                    <th>Orderstatus</th>
                                                    <th>Belopp</th>
                                                    <th>Ta Bort</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($order->id); ?></td>
                                                        <td><?php echo e($order->payment_method); ?></td>
                                                        <td>
                                                            <?php if($order->status == 2): ?>
                                                                <div class="badge bg-primary">I Väntan På</div>
                                                            <?php elseif($order->status == 3): ?>
                                                                <div class="badge bg-info">Plocka upp</div>
                                                            <?php elseif($order->status == 1): ?>
                                                                <div class="badge bg-info">Komplett</div>
                                                            <?php elseif($order->status == 0): ?>
                                                                <div class="badge bg-danger">Avbryt</div>
                                                            <?php endif; ?>
                                                        </td>
                                                        
                                                        <td><?php echo e(strtoupper($currency->value)); ?>

                                                            <?php echo e($order->total + 80.0); ?></td>
                                                        <td>
                                                            <div class="order-btn d-flex">
                                                                
                                                                <a class="ht-btn black-btn"
                                                                    href="<?php echo e(route('author.order.details', encrypt($order->id))); ?>">Visa
                                                                    Detaljer</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->


                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade" id="addresses" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Addresses</h3>
                                    <p><b>Note: </b> Här kan du aktivera leverans tjänsten i ditt område. Genom att flera kunder i samma område lägger till adress i deras konto. Kunder ser inte varandras namn eller adress utan bara information om hur mycket leverans vi har i detta område. Leveransen aktiveras med att fem kunder i samma område gör en beställning.  

                                        Om du inte hittar din stad/ tätort med i vår leverans tjänst. Då har du nytta av denna funktion. Då kan du lägga dina hem eller jobb adresser. Och se om det finns leveranser i ditt område.</p>
                                    <div class="account-details-form">
                                        <form action="<?php echo e(route('author.store.address')); ?>" method="POST"
                                            id="address_form">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="name">Address Namn</label>
                                                    <input type="text" name="address_name" placeholder="Address Namn" id="address_name">
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="city">City</label>
                                                    <input type="text" name="city" placeholder="City"
                                                        id="city">
                                                </div>
                                                <br><br><br><br>
                                                <div class="col-md-12">
                                                    <label for="address">Address</label>
                                                    <input type="text" name="address" placeholder="write your address here...."
                                                        id="address">
                                                </div>
                                                <br><br><br><br>
                                                <div class="col-md-12">
                                                    <button type="submit"
                                                        class="btn btn-warning btn-hover-primary">Submit</button>
                                                </div>
                                                
                                            </div>
                                        </form>
                                    </div>
                                    <br>
                                    <div class="myaccount-table table-responsive text-center">
                                        <table class="table table-bordered">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>Name</th>
                                                    <th>City</th>
                                                    <th>Address</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($address->name); ?></td>
                                                        <td><?php echo e($address->city); ?></td>
                                                        <td><?php echo e($address->address); ?></td>
                                                       
                                                        <td>
                                                            <?php if(in_array(Str::lower($address->city), $cities)): ?>
                                                            <div class="badge bg-primary">Active</div>
                                                            <?php else: ?>
                                                            <?php if($address_count->has([$address->city])): ?>
                                                           
                                                            <?php if($address_count[$address->city] >= 5): ?>
                                                            <div class="badge bg-primary">Active</div>
                                                            <?php else: ?>
                                                                <div class="badge bg-danger"><?php echo e(5 - $address_count[$address->city]); ?> adresser kvar for aktivering av leverans</div>
                                                            <?php endif; ?>
                                                            <?php endif; ?>
                                                            <?php endif; ?>

                                                            
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->

                            <!-- Single Tab Content Start -->
                            <div class="tab-pane fade" id="account-info" role="tabpanel">
                                <div class="myaccount-content">
                                    <h3>Kontouppgifter</h3>

                                    <div class="account-details-form">
                                        <form action="<?php echo e(route('author.settings.update')); ?>" method="POST"
                                            id="user_settings_form">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-lg-6 col-12 mb-5">
                                                    <label for="name">Namn</label>
                                                    <input type="text" name="name" placeholder="Namn" id="name"
                                                        value="<?php echo e(Auth::User()->name); ?>">
                                                </div>

                                                <div class="col-lg-6 col-12 mb-5">
                                                    <label for="email"><?php echo e(__('Email')); ?></label>
                                                    <input type="text" name="email" placeholder="<?php echo e(__('Email')); ?>"
                                                        id="email" value="<?php echo e(Auth::User()->email); ?>">
                                                </div>

                                                <div class="col-12 mb-5">
                                                    <h4>Ändra Lösenord</h4>
                                                </div>

                                                <div class="col-12 mb-5">
                                                    <label for="current_password">Nuvarande lösenord</label>
                                                    <input type="password" placeholder="Nuvarande lösenord"
                                                        name="current_password" id="current_password">
                                                </div>

                                                <div class="col-lg-6 col-12 mb-5">
                                                    <label for="new_password">Nytt lösenord</label>
                                                    <input type="password" class="form-control"
                                                        placeholder="Nytt lösenord" name="password" id="new_password">
                                                </div>

                                                <div class="col-lg-6 col-12 mb-5">
                                                    <label for="confirm_password">Bekräfta lösenord</label>
                                                    <input type="password" class="form-control"
                                                        placeholder="Bekräfta lösenord" name="password_confirmation"
                                                        id="confirm_password">
                                                </div>

                                                <div class="col-12">
                                                    <button type="submit"
                                                        class="btn btn-warning btn-hover-primary">Uppdatera</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Single Tab Content End -->
                        </div>
                    </div>
                </div>
                <!-- My Account Tab Content End -->
            </div>
        </div>
    </div>
    <br><br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/frontend/myaccount.blade.php ENDPATH**/ ?>