<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="card-body">
		<div class="row mb-30">
			<div class="col-lg-6">
				<h4><?php echo e(__('Product List')); ?></h4>
			</div>
			<div class="col-lg-6">
				<div class="add-new-btn">
					<a href="<?php echo e(route('store.product.create')); ?>" class="btn btn-primary f-right"><?php echo e(__('Add New')); ?></a>
				</div>
			</div>
		</div>
		<div class="cart-filter mb-20">

			<a href="<?php echo e(route('store.product.index')); ?>"><?php echo e(__('All')); ?> <span>(<?php echo e(App\Terms::where('type',6)->where('auth_id',$auth_id)->where('status','!=',0)->count()); ?>)</span></a>
			<a href="?st=1"><?php echo e(__('Published')); ?> <span>(<?php echo e(App\Terms::where('type',6)->where('auth_id',$auth_id)->where('status',1)->count()); ?>)</span></a>
			<a href="?st=2"><?php echo e(__('Drafts')); ?> <span>(<?php echo e(App\Terms::where('type',6)->where('auth_id',$auth_id)->where('status',2)->count()); ?>)</span></a>
			<a href="?st=trash" class="trash"><?php echo e(__('Trash')); ?> <span>(<?php echo e(App\Terms::where('type',6)->where('auth_id',$auth_id)->where('status',0)->count()); ?>)</span></a>
		</div>
		<div class="card-action-filter">
			<div class="row mb-10">
				<div class="col-lg-6">
					<form id="basicform" method="post" action="<?php echo e(route('store.products.destroy')); ?>">
						<?php echo csrf_field(); ?>
						<div class="d-flex">
							<div class="single-filter">
								<div class="form-group">
									<select class="form-control" name="status">
										<option><?php echo e(__('Bulk Actions')); ?></option>
										<option value="publish"><?php echo e(__('Publish')); ?></option>
										<option value="trash"><?php echo e(__('Move to Trash')); ?></option>
										<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>
									</select>
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary mt-1 ml-2"><?php echo e(__('Apply')); ?></button>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single-filter f-right">
							<div class="form-group">
								
								<input type="text" id="data_search" class="form-control" placeholder="Enter Value">
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="table-responsive custom-table">
				<table class="table">
					<thead>
						<tr>
							<th class="am-select">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
									<label class="custom-control-label" for="checkAll"></label>
								</div>
							</th>
							<th class="am-title"><i class="far fa-image"></i></th>
							<th class="am-title"><?php echo e(__('Title')); ?></th>
							
							<th class="am-tags"><?php echo e(__('Price')); ?></th>
							<th class="am-tags"><?php echo e(__('Sales')); ?></th>
							
							<th class="am-tags"><?php echo e(__('Status')); ?></th>

							<th class="am-date"><?php echo e(__('Last Modified')); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th>
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($post->id); ?>" value="<?php echo e($post->id); ?>">
									<label class="custom-control-label" for="customCheck<?php echo e($post->id); ?>"></label>
								</div>
							</th>
							<td><img src="<?php echo e(asset($post->preview->content)); ?>" alt="" height="50"></td>
							<td>
								<?php echo e($post->title); ?>

								<div class="hover">
									<a href="<?php echo e(route('store.product.edit',$post->id)); ?>"><?php echo e(__('Edit')); ?></a>

									<a href="<?php echo e(route('store.product.edit',$post->id)); ?>" class="last"><?php echo e(__('View')); ?></a>
								</div>
							</td>
							
							<td><?php echo e($post->price->price); ?></td>
							<td><?php echo e($post->order_count); ?></td>
							
							
							
							
							<td><?php if($post->status==1): ?>  Published <?php elseif($post->status==2): ?>  <?php echo e(__('Draft')); ?> <?php else: ?> <?php echo e(__('Trash')); ?> <?php endif; ?></td>
							<td><?php echo e(__('Last Modified')); ?>

								<div class="date">
									<?php echo e($post->updated_at->diffForHumans()); ?>

								</div>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>

					<tfoot>
						<tr>
							<th class="am-select">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="checkAll">
									<label class="custom-control-label" for="checkAll"></label>
								</div>
							</th>
							<th class="am-title"><i class="far fa-image"></i></th>
							<th class="am-title"><?php echo e(__('Title')); ?></th>
							
							<th class="am-tags"><?php echo e(__('Price')); ?></th>
							<th class="am-tags"><?php echo e(__('Sales')); ?></th>
						
							<th class="am-tags"><?php echo e(__('Status')); ?></th>

							<th class="am-date"><?php echo e(__('Last Modified')); ?></th>
						</tr>
					</tfoot>
				</table>
				<?php echo e($posts->links()); ?>

			</div>
		</div>
	</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script type="text/javascript">
"use strict";	
	//success response will assign this function
	 function success(res){
	 	location.reload();
	 }
	 function errosresponse(xhr){

	 	$("#errors").html("<li class='text-danger'>"+xhr.responseJSON[0]+"</li>")
	 }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/shop/views/products/index.blade.php ENDPATH**/ ?>