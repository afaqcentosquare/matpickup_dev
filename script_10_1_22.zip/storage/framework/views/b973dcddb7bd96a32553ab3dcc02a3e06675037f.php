<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Manage Language')); ?></h6>
	</div>
	<div class="card-body">
		<form action="<?php echo e(route('admin.lang.set')); ?>" method="POST" id="basicform">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-lg-3">
					<div class="form-group">
						<select name="status" class="form-control">
							<option disabled selected><?php echo e(__('Select Option')); ?></option>
							<option value="active"><?php echo e(__('Active Language')); ?></option>
						</select>
					</div>
				</div>
				<input type="hidden" value="<?php echo e($theme_name); ?>" name="theme_name">
				<div class="col-lg-2 pl-0">
					<button type="submit" class="btn btn-primary btn-lg"><?php echo e(__('Submit')); ?></button>
				</div>
				<div class="col-lg-7">
					<a href="<?php echo e(route('admin.language.create')); ?>" class="btn btn-info float-right btn-lg"><?php echo e(__('Add New Language')); ?></a>
				</div>
			</div>
			<table class="table table-bordered">
				<thead>
				<tr>
					<th scope="col">
						<div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
							<label class="custom-control-label checkAll" for="customCheck12"></label>
						</div>
					</th>
					<th scope="col"><?php echo e(__('Language Name')); ?></th>
					<th scope="col"><?php echo e(__('Position')); ?></th>
					<th scope="col"><?php echo e(__('Theme Name')); ?></th>
					<th scope="col"><?php echo e(__('Action')); ?></th>
				</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th scope="row">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" name="lang[]" <?php echo e($lang->status == 1 ? 'checked' : ''); ?> class="custom-control-input" id="customCheck<?php echo e($lang->slug); ?>" value="<?php echo e($lang->slug); ?>">
								<label class="custom-control-label" for="customCheck<?php echo e($lang->slug); ?>"></label>
							</div>
						</th>
						<?php
							$data = json_decode($lang->content,true);
						?>
						<td><?php echo e($data['lang_name']); ?></td>
						<td><?php echo e($data['lang_position']); ?></td>
						<td><?php echo e($lang->name); ?></td>
						<td>
							<a href="<?php echo e(route('admin.lang.edit',['lang_code'=>$lang->slug,'theme_name'=>$lang->name])); ?>" class="btn btn-info mr-2"><?php echo e(__('Customize')); ?></a>
							<a href="<?php echo e(route('admin.lang.delete',['lang_code'=>$lang->slug,'theme_name'=>$lang->name])); ?>" class="btn btn-danger cancel"><?php echo e(__('Delete')); ?></a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script type="text/javascript">
	"use strict";	
	//success response will assign this function
	function success(res){
		location.reload();
	}
	function errosresponse(xhr){

		$("#errors").html("<li class='text-danger'>"+xhr.responseJSON[0]+"</li>")
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/admin/language/index.blade.php ENDPATH**/ ?>