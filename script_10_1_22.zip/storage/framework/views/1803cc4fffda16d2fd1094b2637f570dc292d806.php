<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="custom-control custom-checkbox"><input type="checkbox" name="category[]" class="custom-control-input" value="<?php echo e($category->id); ?>" id="category<?php echo e($category->id); ?>">
	<label class="custom-control-label" for="category<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

	</label>
</div>
<?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('lphelper::lphelper.category.child_category', ['child_category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\files\script\vendor\lpress\src/views/lphelper/category/categories.blade.php ENDPATH**/ ?>