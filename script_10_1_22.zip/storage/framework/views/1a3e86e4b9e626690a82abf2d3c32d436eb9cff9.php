
<?php $__env->startSection('content'); ?>
<?php
$currency=\App\Options::where('key','currency_icon')->select('value')->first();
?>
<div class="row">
	<div class="col-sm-6">
		<div class="card">
			<div class="card-header ">

				<div class="text-center">
					<a href="<?php echo e(route('rider.payout.edit')); ?>" class="text-left"><img src="<?php echo e(asset('uploads/paypal.png')); ?>" height="65"></a>
					<a href="<?php echo e(route('rider.payout.edit')); ?>" class="text-right ml-5"><img src="<?php echo e(asset('uploads/bank.png')); ?>" height="40"></a>
				</div>
			</div>
			<div class="card-body text-left">
				
				<a href="<?php echo e(route('rider.payout.edit')); ?>"><?php echo e(__('Edit Payout Information')); ?></a>
			</div>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="card">
			<div class="card-header ">

				<div class="text-center">
					<a href="#" data-toggle="modal" data-target="#exampleModal"><img src="<?php echo e(asset('uploads/cash.png')); ?>" height="65"></a>
					
				</div>
				<h2 class="text-right ml-5"><strong><?php echo e(strtoupper($currency->value)); ?><?php echo e($total); ?></strong></h2>
			</div>
			<div class="card-body text-left">
				
				<a href="#" data-toggle="modal" data-target="#exampleModal"><?php echo e(__('Withdraw')); ?></a>
			</div>
		</div>
	</div>
	<div class="col-sm-12">
		<div class="card card-primary">
			<div class="card-header">
				<h4><?php echo e(__('Payout History')); ?></h4>
				
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table">
						<tr>
							<th><?php echo e(__('Transaction ID')); ?></th>
							<th><?php echo e(__('Amount')); ?></th>
							<th><?php echo e(__('Payout Method')); ?></th>
							<th><?php echo e(__('Date Processed')); ?></th>
							<th><?php echo e(__('Payout Status')); ?></th>
							
						</tr>

						<?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>#<?php echo e($row->id); ?></td>
							<td><?php echo e($row->amount); ?></td>
							<td><?php echo e(strtoupper($row->payment_mode)); ?></td>
							<td><?php echo e($row->created_at->format('Y-F-d')); ?></td>
							<td><?php if($row->status==0): ?>
								<span class="badge badge-danger"><?php echo e(__('Canceled')); ?></span>
								<?php elseif($row->status==1): ?>
								<span class="badge badge-success"><?php echo e(__('Completed')); ?></span> <?php elseif($row->status==2): ?>
								<span class="badge badge-primary">
									<?php echo e(__('Processing')); ?>


								<?php endif; ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						<?php echo e($payouts->links()); ?>

					</div>
				</div>
			</div>
		</div>

	</div>

	<?php $__env->stopSection(); ?>
	<?php if($total > 0): ?>
	<?php $__env->startSection('extra'); ?>
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Withdraw')); ?></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<form method="post" action="<?php echo e(route('rider.withdraw')); ?>" id="basicform">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="tk" value="<?php echo e($total); ?>">
					<div class="modal-body">
						<div class="form-group">
							<label><?php echo e(__('Amount')); ?></label>
							<input type="number" name="amount" value="<?php echo e($total); ?>" required class="form-control" disabled="">
						</div>
						<div class="form-group">
							<label><?php echo e(__('Select Method')); ?></label>
							<select class="form-control" name="method">
								<option value="paypal">Paypal</option>
								<option value="bank-transfer">Bank Transfer</option>
							</select>
						</div>
					</div>
					
					<div class="modal-footer">
						
						<button type="submit" class="btn btn-primary col-12"><?php echo e(__('Withdraw Now')); ?></button>
					</div>

				</form>

			</div>
		</div>
	</div>

	<?php $__env->stopSection(); ?>
	<?php endif; ?>

	<?php $__env->startSection('script'); ?>
	<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>

	<script type="text/javascript">
		"use strict";
		function success(param) {
			window.location.reload();
		}
	</script>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/rider/statement/payout.blade.php ENDPATH**/ ?>