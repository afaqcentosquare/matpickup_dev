


<?php $__env->startSection("content"); ?>

<nav class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                
            </div>
        </div>
    </div>
</nav>

<div class="shop-product-tab section-pb">
    <div class="container">
        <div class="row mb-n7">
            <div class="col-lg-8 col-xl-9">
                
                  <div id="product_data">
                    <?php if($allCitiesStores->count() > 0): ?>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel">
                                <div class="row grid-view g-0 shop-grid-5">

                                    <?php $__currentLoopData = $allCitiesStores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cityStore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <!-- single slide Start -->
                                    <div class="col-xl-3 col-sm-6">
                                        <div class="product-card">
                                            <a class="thumb" href="<?php echo e(route("user.store.products",$cityStore->users->slug)); ?>">
                                                
                                                    <img src="<?php echo e(asset($cityStore->users->avatar)); ?>" alt="img" />
                                                
                                            </a>
                                            <div class="product-content">
                                                <h3 class="product-title">
                                                    <br>
                                                    <a href="<?php echo e(route("user.store.products",$cityStore->users->slug)); ?>"><?php echo e($cityStore->users->name); ?></a>
                                                </h3>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <!-- single slide End -->
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                

                                </div>
                            </div>
                        </div>
                        <div class="row g-0 align-items-center mt-md-5">
                            <?php echo e($allCitiesStores->onEachSide(1)->links()); ?>

                        </div>
                        <?php else: ?>
                        <h1>No Product Found<h1>
                        <?php endif; ?>
                  </div>
            </div>
            <div class="col-lg-4 col-xl-3 mb-7 order-lg-first">
                <div class="vertical-menu d-none d-lg-block">
                    <button class="menu-btn d-flex">
                        <span class="lnr lnr-text-align-left"></span>Städer
                    </button>
                    <div class="widget-card">
                       
                        <ul id="offcanvas-menu2" class="blog-ctry-menu">
                            <?php $__currentLoopData = $allCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route("area",$city->slug)); ?>"><?php echo e($city->title); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    </div>
                    <!-- menu content -->
                </div>

            </div>
        </div>
    </div>
</div>
<br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\am-content\Themes/khana/views/frontend/area_stores.blade.php ENDPATH**/ ?>