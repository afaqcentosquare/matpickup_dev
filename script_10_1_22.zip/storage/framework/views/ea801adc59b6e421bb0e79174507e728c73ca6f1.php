

<?php $__env->startSection('content'); ?>
<!-- contact area start -->
<section id="contact">
    <div class="contact-area pt-100 pb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="section-header-title text-center pb-30">
                        <h2 id="contact_title"><?php echo e(__('Contact Us')); ?></h2>
                       
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="custom-form">
                        <form action="<?php echo e(route('contact.send')); ?>" method="POST" id="contact_form">
                        <?php echo csrf_field(); ?>                          <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="name" placeholder="<?php echo e(__('Name')); ?>" name="name">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" id="email" placeholder="<?php echo e(__('Email')); ?>" name="email">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="subject" placeholder="<?php echo e(__('Subject')); ?>" name="subject">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <textarea name="message" id="message" class="form-control" cols="30" rows="6" placeholder="<?php echo e(__('Message')); ?>"></textarea>
                                    </div>
                                </div>
                                <div class="col-lg-8 text-center">
                                    <h5 class="text-success pt-15" id="success"></h5>
                                    <h5 class="text-danger" id="error"></h5>
                                </div>
                                <div class="col-lg-4">
                                    <button type="submit" class="btn-submit f-right" id="contact_button_label"><?php echo e(__('Send Message')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\am-content\Themes/khana/views/contact/index.blade.php ENDPATH**/ ?>