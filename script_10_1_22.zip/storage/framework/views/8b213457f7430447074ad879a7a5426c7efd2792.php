
<?php $__env->startSection("content"); ?>
<nav class="breadcrumb-section section-py bg-light2">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="bread-crumb-title">Logga In & Registrera</h3>
                
            </div>
        </div>
    </div>
</nav>

<div class="login-register-area section-py">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 mx-auto">
                <div class="login-register-wrapper">
                    <div class="login-register-tab-list nav nav-tabs" id="nav-tab" role="tablist">
                        <a class="active" data-bs-toggle="tab" href="#lg1">
                            <h4>Logga In</h4>
                        </a>
                        <a data-bs-toggle="tab" href="#lg2">
                            <h4>Registrera</h4>
                        </a>
                    </div>

                    <div class="tab-content">
                        <div id="lg1" class="tab-pane show active">
                            <div class="login-form-container">
                           
                            <?php if(Session::has('errors')): ?>
                            <?php if(is_array(Session::get('errors'))): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="text-danger"><?php echo e($error); ?></span><br><br>
                                <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <span class="text-danger"><?php echo e(Session::get('errors')); ?></span><br><br>
                            <?php endif; ?>
							<?php endif; ?>
                            
                                
                                
                                <div class="login-register-form">
                                    <div class="social-links text-center">
                                        
                                        <h6>Logga In Med Socialt Konto</h6>
                                        <?php if(env('FACEBOOK_CLIENT_ID') != null): ?>
                                        <a class="facebook" href="<?php echo e(url('login/facebook')); ?>"><i class="fa fa-facebook"></i> <?php echo e(__('Facebook')); ?></a>
                                        <?php endif; ?>
        
                                        <?php if(env('GOOGLE_CLIENT_ID') != null): ?>
                                        <a class="google" href="<?php echo e(url('login/google')); ?>"><i class="fa fa-google"></i> <?php echo e(__('Google')); ?></a>
                                        <?php endif; ?>
                                        
                                        <h6>----------ELLER----------</h6>
                                    </div>
                                    <form action="<?php echo e(route('login')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="email" name="email" placeholder="ange din e-postadress" value="<?php echo e(old('email')); ?>"/>
                                        <input type="password" name="password"  placeholder="Lössenord" />
                                       
                                        <div class="button-box">
                                            <div class="login-toggle-btn">
                                                <input type="checkbox"  id="remember" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
                                                <label for="remember">Kom Ihåg Mig</label>
                                                <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot password?')); ?></a>
                                            </div>
                                            <button type="submit" class="btn btn-warning btn-hover-primary">
                                                LOGGA IN 
                                                
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div id="lg2" class="tab-pane">
                            <div class="login-form-container">
                                <div class="login-register-form">
                                   
                                    <form action="<?php echo e(route('user.register')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        
                                        <input type="text" name="name" placeholder="ditt fullständiga namn" />
                                        <input type="text" name="email" placeholder="Din email" />
                                        
                                        
                                        <input type="password" name="password" placeholder="lössenord" />
                                        <input type="password" name="password_confirmation" placeholder="lössenord" type="password_confirmation" />
                                        <div class="button-box">
                                            <div class="login-toggle-btn">
                                                <input type="checkbox"  id="agree" name="agree" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
                                                <label for="remember">Jag <a href="<?php echo e(url('/page/terms-and-conditions')); ?>">Godkänner Villkoren</a></label>
                                            </div>
                                            <button type="submit" class="btn btn-warning btn-hover-primary">
                                                Registrera Nu
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/frontend/auth.blade.php ENDPATH**/ ?>