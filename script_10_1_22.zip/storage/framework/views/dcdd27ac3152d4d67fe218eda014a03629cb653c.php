<?php if($childrens): ?>
  	<li  class="<?php echo e($li); ?>" >
  			<?php if($icon_position=='left'): ?> <i class="<?php echo e($childrens->icon); ?>"></i> <?php endif; ?>
  			<a <?php if(url()->current() == url($row->href)): ?> class="active" <?php endif; ?> href="<?php echo e(url($childrens->href)); ?>" <?php if(!empty($childrens->target)): ?> target=<?php echo e($childrens->target); ?> <?php endif; ?>><?php echo e($childrens->text); ?></a> <?php if($icon_position=='right'): ?> <i class="<?php echo e($childrens->icon); ?>"></i><?php endif; ?>
		<?php if(isset($childrens->children)): ?> 
		<ul  class="<?php echo e($ul); ?>" >
			<?php $__currentLoopData = $childrens->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			 <?php echo $__env->make('lphelper::lphelper.lpmenu.child', ['childrens' => $row], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>	
		<?php endif; ?>
	</li>
<?php endif; ?>


<?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/vendor/lpress/src/views/lphelper/lpmenu/child.blade.php ENDPATH**/ ?>