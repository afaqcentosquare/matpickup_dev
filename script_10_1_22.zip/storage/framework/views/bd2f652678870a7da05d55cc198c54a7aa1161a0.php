
<?php $__env->startSection("content"); ?>
<nav class="breadcrumb-section section-py bg-light2">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3 class="bread-crumb-title">Logga In Med BankId</h3>
                
            </div>
        </div>
    </div>
</nav>

<div class="login-register-area section-py">
    <div class="container">
        <div class="row">
            <div class="col-lg-7 col-md-12 mx-auto">
                <div class="login-register-wrapper">

                    <div class="tab-content">
                        <div id="lg1" class="tab-pane show active">
                            <div class="login-form-container">
                           
                            <?php if(Session::has('errors')): ?>
                            <?php if(is_array(Session::get('errors'))): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="text-danger"><?php echo e($error); ?></span><br><br>
                                <br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <span class="text-danger"><?php echo e(Session::get('errors')); ?></span><br><br>
                            <?php endif; ?>
							<?php endif; ?>
                                
                                <div class="login-register-form">
                                    <div id="loading-div" style="visibility: hidden;" class="d-flex justify-content-center">
                                        <div class="spinner-border text-success" role="status">
                                          <span class="sr-only">Loading...</span>
                                        </div>
                                      </div>
                                      <span id="bankid_error" class="text-danger"></span><br><br>
                                    <form id="bankIdForm">
                                        <?php echo csrf_field(); ?>
                                        <input type="number" id="personal_number" name="personal_number" placeholder="Personnummer" value="<?php echo e(old('personal_number')); ?>"/>
                                        <div class="button-box text-center">
                                            <button type="submit" class="btn btn-warning btn-hover-primary">
                                                LOGGA IN 
                                                
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/frontend/bankid_login_form.blade.php ENDPATH**/ ?>