

<?php $__env->startSection('content'); ?>
<div class="card"  >
	<div class="card-body">
		<div class="row mb-30">
			<div class="col-lg-6">
				<h4><?php echo e(__('Current Featured Seller')); ?></h4>
			</div>
		</div>
		<div class="card-action-filter">
			<form method="post" id="basicform" action="<?php echo e(route('admin.featured.update',1)); ?>">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<div class="row">
					<div class="col-lg-6">
						<div class="d-flex">
							<div class="single-filter">
								<div class="form-group">
									<select class="form-control" name="status">
										<option value="">Select Action</option>
										<option value="trash"><?php echo e(__('Remove From Featured')); ?></option>
									</select>
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary mt-1 ml-1"><?php echo e(__('Apply')); ?></button>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single-filter f-right">
							<div class="form-group">
								<input type="text" id="data_search" class="form-control" placeholder="Enter Value">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="table-responsive custom-table">
				<table class="table">
					<thead>
						<tr>
							<th class="am-select">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
									<label class="custom-control-label checkAll" for="customCheck12"></label>
								</div>
							</th>
							<th class="am-title"><i class="far fa-image"></i></th>
							<th class="am-title"><?php echo e(__('Store Name')); ?></th>
							<th class="am-title"><?php echo e(__('Email')); ?></th>
							
							<th class="am-date"><?php echo e(__('Featured At')); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th>
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($post->f_id); ?>" value="<?php echo e($post->f_id); ?>">
									<label class="custom-control-label" for="customCheck<?php echo e($post->f_id); ?>"></label>
								</div>
							</th>
							<td>
								<img src="<?php echo e(asset($post->avatar)); ?>" height="50">
							</td>
							<td>
								<?php echo e($post->name); ?>

								<div class="hover">
									
									<a href="<?php echo e(url('admin/user',$post->id)); ?>" class="last"><?php echo e(__('View')); ?></a>
								</div>
							</td>
							<td>
								<?php echo e($post->email); ?>

							</td>					
							<td><?php echo e(__('Last Modified')); ?>

								<div class="date">
									<?php echo e($post->created_at->diffForHumans()); ?>

								</div>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</form>
				<tfoot>
					<tr>
						<th class="am-select">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
								<label class="custom-control-label checkAll" for="customCheck12"></label>
							</div>
						</th>
						<th class="am-title"><i class="far fa-image"></i></th>
						<th class="am-title"><?php echo e(__('Store Name')); ?></th>
						<th class="am-title"><?php echo e(__('Email')); ?></th>
						
						<th class="am-date"><?php echo e(__('Featured At')); ?></th>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script>
	"use strict";	
	//response will assign this function
	function success(res){
		location.reload();
	}
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Plugins/locations/views/featured/seller/manage.blade.php ENDPATH**/ ?>