<?php if(!Request::is('store/*')): ?>
<footer id="footer">
    <div class="footer-area pt-70">
        <div class="footer-main-content text-center">
            <div class="footer-menu">
                <nav>
                    <ul>
                        <li>
                            <h4><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a></h4>
                        </li>
                        <li>
                            <h4><a href="<?php echo e(url('/contact')); ?>"><?php echo e(__('Contact')); ?></a></h4>
                        </li>
                        <li>
                            <h4><a href="<?php echo e(url('/page/privacy-policy')); ?>"><?php echo e(__('Privacy Policy')); ?></a></h4>
                        </li>
                        <li>
                            <h4><a href="<?php echo e(url('/page/terms-and-conditions')); ?>"><?php echo e(__('Terms & Conditions')); ?></a></h4>
                        </li>
                        <li>
                            <h4><a href="<?php echo e(url('/page/refund-return-policy')); ?>"><?php echo e(__('Refund & Return Policy')); ?></a></h4>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="footer-copyright">
                <p id="copyright_area"><?php echo e(content('footer','copyright_area')); ?></p>
            </div>
        </div>
    </div>
</footer>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Themes/khana/views/layouts/partials/footer.blade.php ENDPATH**/ ?>