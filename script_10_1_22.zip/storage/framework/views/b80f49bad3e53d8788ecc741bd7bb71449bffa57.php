<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.backend.partials.headersection',['title'=>isset($type) ? ucfirst($type).' Orders' : 'Orders List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
	<div class="col-12 mt-2">
		<div class="card">
			<div class="card-body">
				
				<div class="float-right">
					<form action="<?php echo e(route('admin.order.index')); ?>">
						<div class="input-group mb-2 col-12">

							<input type="text" class="form-control" placeholder="Search..."  name="src" autocomplete="off" value="<?php echo e($src ?? ''); ?>">
							<select class="form-control" name="type">
								<option value="id"><?php echo e(__('Search By Order Id')); ?></option>
							</select>
							<div class="input-group-append">                                            
								<button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
							</div>
						</div>
					</form>
				</div>
				<div class="float-left">
					<form action="<?php echo e(route('admin.order.date.filter')); ?>" method="GET">
						<div class="d-flex">
							<div class="form-group">
								<div class="input-group">
									<div class="input-group-prepend">
										<div class="input-group-text">
											<i class="fas fa-calendar"></i>
										</div>
									</div>
									<input type="text" name="date" class="form-control daterange-cus">
									<input type="hidden" name="type" value="<?php echo e(isset($type) ? $type : ''); ?>">
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary btn-lg ml-2"><?php echo e(__('Filter')); ?></button>
							</div>
						</div>
					</form>

				</div>
				<table class="table">
					<thead>
						<tr>
							<th class="am-title"><?php echo e(__('Order Id')); ?></th>
							<th class="am-author"><?php echo e(__('Restaurant Name')); ?></th>
							<th class="am-tags"><?php echo e(__('Order Type')); ?></th>
							<th class="am-tags"><?php echo e(__('Payment Method')); ?></th>
							<th class="am-tags"><?php echo e(__('Total Amount')); ?></th>
							<th class="am-tags"><?php echo e(__('Status')); ?></th>
							<th class="am-tags"><?php echo e(__('Payment Status')); ?></th>
							<th class="am-date"><?php echo e(__('Action')); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if($orders->count() > 0): ?>
						<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>#<?php echo e($order->id); ?></td>
							<td><?php echo e(isset(App\User::where("id",$order->vendor_id)->first()->name) ? App\User::where("id",$order->vendor_id)->first()->name : ''); ?></td>
							<td><?php if($order->order_type == 1): ?> <?php echo e(__('Home Delivery')); ?> <?php else: ?> <?php echo e(__('Pickup')); ?> <?php endif; ?></td>
							<td><?php echo e(strtoupper($order->payment_method)); ?></td>
							<td><?php echo e(number_format($order->total+$order->shipping,2)); ?></td>
							<td><?php if($order->status == 1): ?> <span class="badge badge-success"><?php echo e(__('Completed')); ?></span> <?php elseif($order->status == 2): ?> <span class="badge badge-primary"> <?php echo e(__('Pending')); ?> </span> <?php elseif($order->status == 3): ?> <span class="badge badge-warning"> <?php echo e(__('Accepted')); ?> </span> <?php elseif($order->status == 0): ?>  <span class="badge badge-danger"> <?php echo e(__('Cancelled')); ?> </span> <?php endif; ?></td>

							<td><?php if($order->payment_status == 1): ?> <span class="badge badge-success"><?php echo e(__('Completed')); ?></span> <?php elseif($order->payment_status == 0): ?>  <span class="badge badge-danger"> <?php echo e(__('Pending')); ?> </span> <?php endif; ?></td>
							<td>
							<div class="btn-group">
                      <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Options
                      </button>
                      <div class="dropdown-menu" x-placement="top-start" >
                        <div class="dropdown-title">Order No #<?php echo e($order->id); ?></div>
                        <a class="dropdown-item" href="<?php echo e(route('admin.order.details',$order->id)); ?>"><?php echo e(__('View')); ?></a>
                        <a class="dropdown-item cancel" href="<?php echo e(route('admin.order.delete',$order->id)); ?>"><?php echo e(__('Delete')); ?></a>
                       
                      </div>
                    </div>
                    </td>
							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<tr>
							<td></td>
							<td></td>
							<td><?php echo e(__('No Data Found')); ?></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
						<?php endif; ?>
					</tbody>
					
				</table>
				<?php echo e($orders->links()); ?>



			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/daterangepicker.min.js')); ?>"></script>
<script type="text/javascript">
	"use strict";	
	//success response will assign this function
	function success(res){
		location.reload();
	}
	$('.daterange-cus').daterangepicker();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/admin/order/index.blade.php ENDPATH**/ ?>