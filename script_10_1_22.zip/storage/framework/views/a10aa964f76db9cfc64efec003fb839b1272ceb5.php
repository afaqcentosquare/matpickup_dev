
<?php $__env->startSection("content"); ?>
<!-- bread-crumb2 start -->
<nav class="breadcrumb-section">
    <div class="container wrapper">
        <div class="row">
            <div class="col-12">
                
            </div>
        </div>
    </div>
</nav>
<!-- bread-crumb2 start -->
<div class="single-product-wrap">
    <div class="container wrapper">
        <div class="row mb-n10">
            <?php if($single_product != null): ?>
            <div class="col-lg-5 mb-10">
                <div class="single-img">
                    <?php if($single_product->preview != null): ?>
                    <?php if(str_contains($single_product->preview->content, 'http')): ?>
                        <img src="<?php echo e($single_product->preview->content); ?>" alt="">
                        <?php else: ?>
                        <img src="<?php echo e(asset($single_product->preview->content)); ?>" alt="img" />
                    <?php endif; ?>
                    <?php else: ?>
                    <img src="<?php echo e(asset($single_product->preview->content)); ?>" alt="img" />
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-7 mb-10">
                <div class="content">
                    <h3 class="title"><?php echo e($single_product->title); ?></h3>
                    <div class="mb-4">
                        <?php
                        $currency=\App\Options::where('key','currency_name')->select('value')->first();
                        ?>
                        <span class="price-lg regular-price d-inline-block mx-1"><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($single_product->price->price,2)); ?></span>
                    </div>
                    <p class="border-bottom pb-4">
                        <?php echo $single_product->excerpt->content; ?>

                    </p>

                    
                    <div class="product-count style d-flex my-4">
                        
                        <div>
                            
                            <input type="hidden" id="add_to_cart_url" value="<?php echo e(url('add_to_cart')); ?>">
                            <a href="javascript:void(0)" onclick="product_add_to_cart('<?php echo e($single_product->slug); ?>','<?php echo e($single_product->user->slug); ?>')" class="btn btn-warning btn-hover-primary text-uppercase">
                                Lägg i kundvagn
                            </a>
                        </div>
                    </div>
                    
                </div>
            </div>
            <?php else: ?>
            <h1>No Product Found :(</h1>
            <br><br><br><br><br><br>
            <?php endif; ?>
            
        </div>
    </div>
</div>

<br><br>

<!-- Product tab Start -->
<section class="section section-pb">
    <div class="container wrapper">
        <div class="row">
            <div class="col-12">
                <div class="title-section">
                    <!-- title section Start -->
                    <h3 class="title">related products</h3>
                    <!-- title section End -->
                </div>
            </div>

            <div class="col-12">
                <div class="product-carousel6">
                    <div class="d-none d-sm-block swiper-navination-arrows">
                        <div class="swiper-button-prev">
                            <span class="ion-android-arrow-back"></span>
                        </div>
                        <div class="swiper-button-next">
                            <span class="ion-android-arrow-forward"></span>
                        </div>
                    </div>
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($related_product->preview != null && $related_product->price != null): ?>
                                <!-- single slide Start -->
                            <div class="swiper-slide">
                                <div class="product-card">
                                    <a class="thumb" href="<?php echo e(route("single.product",$related_product->slug)); ?>">
                                        <?php if(str_contains($related_product->preview->content, 'http')): ?>
                                            <img src="<?php echo e($related_product->preview->content); ?>" alt="" >
                                            <?php else: ?>
                                            <img src="<?php echo e(asset($related_product->preview->content)); ?>" alt="img" />
                                        <?php endif; ?>

                                        <div class="onsales-badges">
                                            <span class="badge bg-dark">new</span>
                                        </div>
                                    </a>
                                    <div class="product-content">
                                        
                                        <h3 class="product-title">
                                            <a href="<?php echo e(route("single.product",$related_product->slug)); ?>"><?php echo e($related_product->title); ?></a>
                                        </h3>
                                        <?php
                                        $currency=\App\Options::where('key','currency_name')->select('value')->first();
                                        ?>
                                        <span class="price regular-price"><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($related_product->price->price,2)); ?></span>
                                        <a class="product-btn btn btn-warning btn-hover-primary" href="javascript:void(0)" onclick="product_add_to_cart('<?php echo e($related_product->slug); ?>','<?php echo e($related_product->user->slug); ?>')">
                                            Lägg i kundvagn
                                        </a>
                                    </div>
                                    <!-- actions links start -->
                                    
                                    <!-- actions links end -->
                                </div>
                            </div>
                            <!-- single slide End -->
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Product tab End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/frontend/single_product.blade.php ENDPATH**/ ?>