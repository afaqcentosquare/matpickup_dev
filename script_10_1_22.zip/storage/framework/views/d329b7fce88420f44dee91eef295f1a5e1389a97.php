<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo e(env('APP_NAME')); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('uploads/favicon.ico')); ?>">
  <!-- General CSS Files -->
 <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.min.css')); ?>">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/components.css')); ?>">
</head>

<body>
  <div id="app">
    <section class="section">
      <div class="d-flex flex-wrap align-items-stretch">
        <div class="col-lg-4 col-md-6 col-12 order-lg-1 min-vh-100 order-2 bg-white">
          <div class="p-4 m-3">
            <h4 class="text-dark font-weight-normal"><?php echo e(__('Welcome to')); ?> <span class="font-weight-bold"><?php echo e(env('APP_NAME')); ?></span></h4>
             <form method="POST" id="basicform" class="needs-validation" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus >
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <div class="d-block">
                  <label for="password" class="control-label"><?php echo e(__('Password')); ?></label>
                </div>
                <input id="password" type="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

               <div class="form-group">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember-me" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                  <label class="custom-control-label" for="remember-me"><?php echo e(__('Remember Me')); ?></label>
                </div>
              </div>

              <div class="form-group text-right">
                 <?php if(Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>" class="float-left mt-3">
                  <?php echo e(__('Forgot Your Password?')); ?>

                </a>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary btn-lg btn-icon icon-right" tabindex="4">
                   <?php echo e(__('Login')); ?>

                </button>
              </div>

              
            </form>

           
          </div>
        </div>
        <div class="col-lg-8 col-12 order-lg-2 order-1 min-vh-100 background-walk-y position-relative overlay-gradient-bottom" data-background="<?php echo e(asset('admin/login-bg.jpg')); ?>">
          
        </div>
      </div>
    </section>
  </div>

  <!-- General JS Scripts -->
  <script src="<?php echo e(asset('admin/assets/js/jquery-3.5.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>

  <!-- Template JS File -->
  <script src="<?php echo e(asset('admin/assets/js/scripts.js')); ?>"></script>
</body>
</html>




<?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\resources\views/auth/login.blade.php ENDPATH**/ ?>