<?php 


Route::group(['namespace'=>'Amcoders\Plugin\contactform\http\controllers'],function(){
	Route::get('contactform',function(){
		return "contactform";
	});
});
