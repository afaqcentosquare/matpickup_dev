
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo e(env('APP_NAME')); ?></title>

  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.min.css')); ?>">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/components.css')); ?>">
</head>

<body>
    <div class="verify-email-address">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card text-center">
                        <div class="card-body pt-5 pb-5">
                            <h4><?php echo e(__("Your request is sent successfully and it's pending for approval")); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>



<?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\am-content\Themes/khana/views/rider/approval.blade.php ENDPATH**/ ?>