<?php $__env->startSection('style'); ?>
<?php if(Amcoders\Plugin\Plugin::is_active('WebNotification')): ?> 
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  "use strict";
  window.OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: '<?php echo e(env('ONESIGNAL_APP_ID')); ?>',
      notifyButton: {
        enable: true,
      },
      subdomainName: "<?php echo e(env('ONESIGNAL_SUB_DOMAIN')); ?>",
    });
    OneSignal.on('subscriptionChange', function (isSubscribed) {
      OneSignal.getUserId(function(userId) {
       $('#signal_user_id').val(userId);
       $('#hiddenbtn').click();   
     });
    });
  });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<form method="post" id="basicform" action="<?php echo e(route('store.subscribe')); ?>">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="player_id"  id="signal_user_id" >
  <button type="hidden" class="none" id="hiddenbtn"></button>
</form>

<div class="row">
  <div class="col-lg-3 col-md-6 col-sm-6 col-12">
    <div class="card card-statistic-1">
      <div class="card-icon">
        <?php if(Auth::user()->status=='approved'): ?>
        <img src="<?php echo e(asset('uploads/open.png')); ?>" height="60">
        <?php else: ?>
        <img src="<?php echo e(asset('uploads/close.png')); ?>" height="60">
        <?php endif; ?>
      </div>
      <div class="card-wrap">
        <div class="card-header">
         <?php if(Auth::user()->status=='approved'): ?>
         <h4><?php echo e(__('Resturant Open')); ?></h4>
         <?php else: ?>
         <h4><?php echo e(__('Resturant Close')); ?></h4>
         <?php endif; ?>
       </div>
       <div class="card-body">
        <?php if(Auth::user()->status=='approved' || Auth::user()->status=='offline'): ?>
        <form action="<?php echo e(route('store.status')); ?>" method="post">
          <?php echo csrf_field(); ?>

          <?php if(Auth::user()->status=='approved'): ?>
          <input type="hidden" name="status" value="offline">
          <button class="btn btn-danger btn-sm text-white mt-2"><?php echo e(__('Turn Off')); ?></button>
          <?php else: ?>
          <input type="hidden" name="status" value="approved">
          <button class="btn btn-success btn-sm text-white mt-2"><?php echo e(__('Turn On')); ?></button>
          <?php endif; ?>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-12">
  <div class="card card-statistic-1">
    <div class="card-icon">
      <img src="<?php echo e(asset('uploads/money.png')); ?>" height="60">
    </div>
    <div class="card-wrap">
      <div class="card-header">
        <h4><?php echo e(__('Total Earnings')); ?></h4>
      </div>
      <div class="card-body">
        <?php echo e(number_format($totals,2)); ?>

      </div>
    </div>
  </div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6 col-12">
  <div class="card card-statistic-1">
    <div class="card-icon">
      <img src="<?php echo e(asset('uploads/salary.png')); ?>" height="60">

    </div>
    <div class="card-wrap">
      <div class="card-header">
        <h4><?php echo e(__('Earnings In this Month')); ?></h4>
      </div>
      <div class="card-body">
        <?php echo e(number_format($earningMonth,2)); ?>

      </div>
    </div>
  </div>
</div>
<?php if(Auth::user()->badge): ?>
<div class="col-lg-3 col-md-6 col-sm-6 col-12">
  <div class="card card-statistic-1">
    <div class="card-icon">
      <img height="80" class="rounded pb-1 mb-1" src="<?php echo e(asset(Auth::user()->badge->preview->content ?? null)); ?>">
    </div>
    <div class="card-wrap">
      <div class="card-header">
        <h4><?php echo e(__('Your Badge')); ?></h4>
      </div>
      <div class="card-body">
        <?php echo e(Auth::user()->badge->title ?? ''); ?>

      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<?php if(!empty($notice)): ?>
<div class="col-lg-6 col-md-6 col-12 col-sm-12">
  <?php else: ?>
  <div class="col-lg-12 col-md-12 col-12 col-sm-12"> 
    <?php endif; ?>  

    <div class="card card-primary">
      <div class="card-header">
        <h4><?php echo e(__('Latest Order')); ?></h4>
        <div class="card-header-action">
          <a href="<?php echo e(route('store.order.index')); ?>" class="btn btn-primary">View All</a>
        </div>
      </div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-striped mb-0">
            <thead>
              <tr>
                <th><?php echo e(__('Order')); ?></th>
                <th><?php echo e(__('Amount')); ?></th>
                <th><?php echo e(__('Status')); ?></th>
                <th><?php echo e(__('Payment Status')); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e(__('Order No')); ?> #<?php echo e($row->id); ?>

                  <div class="table-links">
                    <?php if($row->order_type==1): ?>
                    <a href="<?php echo e(route('store.order.show',$row->id)); ?>"><?php echo e(__('Home Delivery')); ?></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('store.order.show',$row->id)); ?>"><?php echo e(__('Pickup')); ?></a>
                    <?php endif; ?>
                    <div class="bullet"></div>
                    <a href="<?php echo e(route('store.order.show',$row->id)); ?>"><?php echo e(__('View Order')); ?></a>
                    <div class="bullet"></div>
                    <a href="<?php echo e(route('store.invoice',$row->id)); ?>"><?php echo e(__('Download Invoice')); ?></a>
                  </div>
                </td>
                <td>
                  <?php echo e(number_format($row->total,2)); ?>

                </td>
                <td><?php if($row->status == 1): ?> 
                  <span class="badge badge-success"><?php echo e(__('Completed')); ?></span> 
                  <?php elseif($row->status == 2): ?> 
                  <span class="badge badge-primary"> <?php echo e(__('Pending')); ?> </span>
                   <?php elseif($row->status == 3): ?> <span class="badge badge-warning"> <?php echo e(__('Accepted')); ?> </span> 
                   <?php elseif($row->status == 0): ?>  <span class="badge badge-danger"> <?php echo e(__('Cancelled')); ?> </span>
                    <?php endif; ?></td>


                <td><?php if($row->payment_status == 1): ?> 
                  <span class="badge badge-success"><?php echo e(__('Completed')); ?></span> 
                  <?php elseif($row->payment_status == 0): ?>  <span class="badge badge-danger"> <?php echo e(__('Pending')); ?> </span> 
                <?php endif; ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($orders->links()); ?>

        </div>
      </div>
    </div>
  </div>


  <?php if(!empty($notice)): ?>
  <?php
  $json=json_decode($notice->value);
  ?>
  <div class="col-lg-6 col-md-6 col-12 col-sm-12">
    <div class="card card-danger">
      <div class="card-header">
        <h4><?php echo e(__('Announcement')); ?></h4>
      </div>
      <div class="card-body">
        <h5><?php echo e($json->title); ?></h5>
        <p><?php echo e($json->message); ?></p>
      </div>
    </div>
  </div>
  <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script type="text/javascript">
  "use strict";
  function success(arg) {
    //window.location.reload();
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/shop/dashboard.blade.php ENDPATH**/ ?>