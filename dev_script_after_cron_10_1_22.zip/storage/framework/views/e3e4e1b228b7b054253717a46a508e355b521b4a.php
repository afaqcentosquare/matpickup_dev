<?php if($products->count() > 0): ?>
<div class="tab-content" id="myTabContent">
    <div class="tab-pane fade show active" id="home" role="tabpanel">
        <div class="row grid-view g-0 shop-grid-5">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($product->price != null): ?>
                <!-- single slide Start -->
            <div class="col-xl-3 col-sm-6">
                <div class="product-card">
                    <a class="thumb" href="<?php echo e(route("single.product",$product->slug)); ?>">
                        <?php if(str_contains($product->preview->content, 'http')): ?>
                            <img src="<?php echo e($product->preview->content); ?>" alt="">
                            <?php else: ?>
                            <img src="<?php echo e(asset($product->preview->content)); ?>" alt="img" />
                        <?php endif; ?>
                        
                    </a>
                    <div class="product-content">
                        <h3 class="product-title">
                            <br>
                            <a href="<?php echo e(route("single.product",$product->slug)); ?>"><?php echo e($product->title); ?></a>
                        </h3>
                        <?php
                        $currency=\App\Options::where('key','currency_name')->select('value')->first();
                        ?>
                        <span class="price regular-price"><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($product->price->price,2)); ?></span>
                        <input type="hidden" id="add_to_cart_url" value="<?php echo e(url('add_to_cart')); ?>">
                        <a class="product-btn btn btn-warning btn-hover-primary" href="javascript:void(0)" onclick="product_add_to_cart('<?php echo e($product->slug); ?>','<?php echo e($product->user->slug); ?>')">
                            Lägg i kundvagn
                        </a>
                    </div>
                </div>
            </div>
            <!-- single slide End -->
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           

        </div>
    </div>
</div>
<div class="row g-0 align-items-center mt-md-5">
    <?php echo e($products->onEachSide(1)->links()); ?>

</div>
<?php else: ?>
<h1>No Stores Found<h1>
<?php endif; ?>
<?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\am-content\Themes/khana/views/frontend/store_products_view.blade.php ENDPATH**/ ?>