
<?php $__env->startSection("search_form"); ?>
<form action="<?php echo e(route('search.product')); ?>" method="GET">
    <div class="input-group border">
        <input type="text" class="form-control typeahead" placeholder="Ange din söknyckel ... " name="copy_search" autocomplete="off" id="typeahead"/>
        <input type="text" name="selected_serach_text" id="selected_serach_text" hidden/>
        
        <div class="input-group-text">
            <button id="search_button" class="btn-search btn btn-hover-primary" type="submit">
                Sök
            </button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("search_form_mobile"); ?>
<form action="<?php echo e(route('search.product')); ?>" method="GET" class="offcanvas-form">
    <div class="input-group border">
        
        <input type="text" class="form-control typeahead_mob border-0" placeholder="Ange din söknyckel ... " name="copy_search"  autocomplete="off" id="typeahead_mob"/>
        <input type="text" name="selected_serach_text" id="selected_serach_text_mob" hidden/>
        <div class="input-group-text">
            <button id="search_button_mob" class="btn-search btn btn-hover-primary" type="submit">
                Sök
            </button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<input type="text" name="store_id" value="<?php echo e($store_data->slug); ?>" hidden/>
<input type="text" id="store_pure_id" name="store_pure_id" value="<?php echo e($store_data->id); ?>" hidden/>
<nav class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                
            </div>
        </div>
    </div>
</nav>

<div class="shop-product-tab section-pb">
    <div class="container">
        <div class="row mb-n7">
            <div class="col-lg-8 col-xl-9">
                <?php if($store_data->preview != null): ?>
                <img class="mb-4" src="<?php echo e(asset($store_data->preview->content)); ?>" alt="banner" width="100%" height="270px"/>
                <?php endif; ?>
                <div id="loading-div" style="visibility: hidden;" class="d-flex justify-content-center">
                    <div class="spinner-border text-success" role="status">
                      <span class="sr-only">Loading...</span>
                    </div>
                  </div>
                  <div id="product_data">
                    <?php echo $__env->make("theme::frontend.store_products_view", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
            </div>
            <div class="col-lg-4 col-xl-3 mb-7 order-lg-first">
                <div class="vertical-menu d-none d-lg-block">
                    <button class="menu-btn d-flex">
                        <span class="lnr lnr-text-align-left"></span>Kategorier
                    </button>
                    <div class="widget-card">
                       
                        <ul id="offcanvas-menu2" class="blog-ctry-menu">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="javascript:void(0);" onClick="getData(this)" value="<?php echo e($category->slug); ?>"> <?php echo e($category->name); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    </div>
                    <!-- menu content -->
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/frontend/store_products.blade.php ENDPATH**/ ?>