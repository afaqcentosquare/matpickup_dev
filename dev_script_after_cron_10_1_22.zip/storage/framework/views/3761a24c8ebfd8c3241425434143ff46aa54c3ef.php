﻿
<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="mobile-category-nav d-lg-none pt-4">
                <!--=======  category menu  =======-->
                <div class="hero-side-category">
                    <!-- Category Toggle Wrap -->
                    <div class="category-toggle-wrap">
                        <!-- Category Toggle -->
                        <button class="more-btn">
                            <span class="lnr lnr-text-align-left"></span>Städer Många
                        </button>
                    </div>

                    <!-- Category Menu -->
                    <nav class="category-menu">
                        <ul>
                            <?php $__currentLoopData = $allCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route("area",$allCity->slug)); ?>"><?php echo e($allCity->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- Hero Slider Start -->
<section class="hero-section position-relative">
    <div class="container">
        <div class="row mb-n7">
            <div class="col-xl-3 col-lg-4">
                <div class="vertical-menu d-none d-lg-block">
                    <button class="menu-btn d-flex">
                        <span class="lnr lnr-text-align-left"></span>Städer
                    </button>
                    <ul class="vmenu-content">
                        <?php $__currentLoopData = $allCities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="menu-item"><a href="<?php echo e(route("area",$allCity->slug)); ?>"><?php echo e($allCity->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- menu content -->
                </div>

            </div>
            <div class="col-xl-6 col-lg-8">
                <div class="hero-slider position-relative">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <video width="100%" height="500" loop="true" autoplay="autoplay" controls="controls" id="vid" muted>
                                <source src="https://matpickup.se/movie/matpickup.mp4" type="video/mp4">
                                Your browser does not support the video tag.
                              </video>
                        </div>
                    </div>
                </div>
            </div>
            
                    
                    
        </div>
    </div>
</section>
<!-- Hero Slider End -->

<section class="section-pt">
    <div class="container">
        <div class="row g-0">
            <?php $__currentLoopData = $allCitiesStores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCitiesStore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="d-flex custom-flex-column">
                    
                        <div class="product-card">
                            <a class="thumb" href="<?php echo e(route("area",$allCitiesStore->slug)); ?>">
                                    <img src="<?php echo e(asset($allCitiesStore->preview->content)); ?>" alt="" width="350px" height="235px">
                                
                            </a>
                            <div class="product-content">
                                <h3 class="product-title">
                                    <br>
                                    <a href="<?php echo e(route("area",$allCitiesStore->slug)); ?>"><?php echo e($allCitiesStore->title); ?></a>
                                </h3>
                            </div>
                        </div>
                    
                   
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<br><br>


<section class="static-media-section bg-primary section-py">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-6 py-3">
                <div class="d-flex static-media flex-column flex-sm-row">
                    <img class="align-self-center mb-2 mb-sm-0 me-auto me-sm-3" src="<?php echo e(theme_asset('khana/public/frontend/assets/images/icon/2.png')); ?>" alt="icon">
                    <div class="media-body">
                        <h4 class="title text-capitalize text-white">Hem Leverans</h4>
                        <p class="text text-white">60 mins</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-sm-6 py-3">
                <div class="d-flex static-media flex-column flex-sm-row">
                    <img class="align-self-center mb-2 mb-sm-0 me-auto me-sm-3" src="<?php echo e(theme_asset('khana/public/frontend/assets/images/icon/5.png')); ?>" alt="icon">
                    <div class="media-body">
                        <h4 class="title text-capitalize text-white">Support 24/7</h4>
                        <p class="text text-white">Kontakta Oss 24 Timmar Om Dygnet</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6 py-3">
                <div class="d-flex static-media flex-column flex-sm-row">
                    <img class="align-self-center mb-2 mb-sm-0 me-auto me-sm-3" src="<?php echo e(theme_asset('khana/public/frontend/assets/images/icon/4.png')); ?>" alt="icon">
                    <div class="media-body">
                        <h4 class="title text-capitalize text-white">
                            100% Betalning Säker
                        </h4>
                        <p class="text text-white">Din betalning 100 % säker och krypterat</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($store_product->productsTerm->count() > 0): ?>
     <!-- Product tab Start -->
 <section class="section-pt">
    <div class="container">
        <div class="row g-0">
            <div class="col-12">
                <div class="title-section text-center text-lg-start">
                    <div class="row">
                        <!-- title section Start -->
                        <div class="col-12 col-lg-4">
                            <h3 class="title"><?php echo e($store_product->name); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="tab-content">
            <div class="tab-pane fade show active" id="pots">
                <div class="row mb-n7">
                    
                    <div class="col-lg-12 col-xl-12 mb-7">
                        <div class="row">
                            <?php $__currentLoopData = $store_product->productsTerm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3">
                                <div class="media-list mb-4">
                                    <div class="media">
                                        <a class="thumb" href="<?php echo e(route("single.product",$product->slug)); ?>">
                                            <?php if(str_contains($product->content, 'http')): ?>
                                            <img src="<?php echo e($product->content); ?>" alt="" width="105px" height="105px">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset($product->content)); ?>" alt="img" width="105px" height="105px"/>
                                            <?php endif; ?>
                                            
                                        </a>
                                        <div class="media-body">
                                            <h3 class="product-title">
                                                <a href="<?php echo e(route("single.product",$product->slug)); ?>"><?php echo e($product->title); ?></a>
                                            </h3>
                                            <?php
                                            $currency=\App\Options::where('key','currency_name')->select('value')->first();
                                            ?>
                                            <span class="price-lg regular-price"><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($product->price,2)); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Product tab End -->
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <!-- adto cart -->
    <!-- Modal -->
    <div class="modal fade" id="postal_search" tabindex="-1" aria-labelledby="add-to-cart">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary border-bottom-0 justify-content-center">
                    <h4 class="modal-title text-center text-white">Search by Postal code or City</h4>
                </div>
                <div class="modal-body p-5">
                    <form action="<?php echo e(route('resturents.search.city')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="row">
                            <div class="col-md-12 mb-5">
                                <label for="postal_code">Search By Postal Code Or City</label>
                                <input type="text" name="postal_code" class="form-control" placeholder="search by postal code or city" id="postal_code">
                            </div>
                        </div>
                    </div class="row">
                        <div class="cart-content-btn text-center">
                            <button class="btn btn-warning btn-hover-primary text-uppercase" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
                            <button type="submit" class="btn btn-warning btn-hover-primary text-uppercase">Submit</button>
                        </div>
                    </div>
                </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/frontend/home.blade.php ENDPATH**/ ?>