<?php echo e($slot); ?>

<?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>