

<?php $__env->startSection('content'); ?>

<div class="section-body">
 <div class="row">
  <div class="col-12 col-md-12 col-lg-7">
    <div class="card">

      <div class="card-header">
        <h4><?php echo e(__('Orders')); ?></h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover text-center">
            <thead>
              <tr>
                
                <th scope="col"><?php echo e(__('Item Name')); ?></th>
                <th scope="col"><?php echo e(__('Quantity')); ?></th>
                <th scope="col"><?php echo e(__('Total Amount')); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php
              $subtotal=0;
              ?>
              <?php $__currentLoopData = $info->orderlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $itemrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
              $total= $itemrow->total+$subtotal;
              $subtotal = $total; 
              ?>
              <tr>
               
                <td><?php echo e($itemrow->products->title ?? ''); ?></td>
                <td><?php echo e($itemrow->qty ?? ''); ?></td>
                <td><?php echo e(number_format($itemrow->total*$itemrow->qty,2)); ?></td>
                
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <div class="text-left">
        
          <?php if($info->coupon_id != null): ?>
          <p><b>Discount Code: </b>  <?php echo e($info->coupon->title ?? ''); ?></p>
          
          <?php endif; ?>
          <p><b>Subtotal: </b>  <?php echo e(number_format($info->total,2)); ?></p>
          <p><b>Shipping: </b>  <?php echo e(number_format($info->shipping,2)); ?></p>
          <p><b>Total: </b>  <?php echo e(number_format($info->shipping+$info->total,2)); ?></p>
        </div>
      </div>
     
      <div class="card-footer">
        <form method="post" id="basicform" action="<?php echo e(route('admin.order.update',$info->id)); ?>">
          <?php echo csrf_field(); ?>
         
          <div class="row">
            <?php if($info->order_type == 1): ?>
            
            <div class="form-group col-lg-6">
              <label><?php echo e(__('Select Rider')); ?></label>
              <select class="form-control" name="rider">
                <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($row->user_id); ?>"><?php echo e($row->riders->name); ?> (#<?php echo e($row->user_id); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            
            <?php endif; ?>
            <?php if($info->order_type == 1): ?>
            <div class="form-group col-lg-6">
             <?php elseif(empty($info->rider_id)): ?>
             <div class="form-group col-lg-12">
               <?php else: ?>
               <div class="form-group col-lg-12">
                <?php endif; ?>
               
                <label><?php echo e(__('Order Status')); ?></label>
                <select class="form-control" name="status">
                  <option value="2" <?php if($info->status==2): ?> selected="" <?php endif; ?>><?php echo e(__('Order Pending')); ?></option>
                  <option value="3" <?php if($info->status==3): ?> selected="" <?php endif; ?>><?php echo e(__('Accept Order')); ?></option>
                  <option value="1" <?php if($info->status==1): ?> selected="" <?php endif; ?>><?php echo e(__('Order Complete')); ?></option>
                  <option value="0" <?php if($info->status==0): ?> selected="" <?php endif; ?>><?php echo e(__('Decline Order')); ?></option>
                </select>
                
              </div>
            </div>
            <button type="submit" class="btn btn-primary col-12 submit-btn"><?php echo e(__('Processed')); ?></button>
          </form>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          <h5 class="text-primary text-center"><?php echo e(__('Order Log')); ?></h5>
        </div>
        <div class="card-body">

          <div class="activities">

            <div class="activity">
              <div class="activity-icon bg-primary text-white shadow-primary">
                <i class="far fa-paper-plane"></i>
              </div>
              <div class="activity-detail">
                <div class="mb-2">
                  <span class="text-job text-primary"><?php echo e($info->created_at->diffForHumans()); ?></span>
                  <span class="bullet"></span>

                </div>
                <p><?php echo e(__('Order Created')); ?></p>
              </div>
            </div>

            <?php $__currentLoopData = $info->orderlog ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="activity">
              <div class="activity-icon bg-primary text-white shadow-primary">
               <?php if($row->status == 3): ?>
               <i class="fas fa-comment-alt"></i>
               <?php elseif($row->status == 2): ?>
               <i class="far fa-paper-plane"></i>
               <?php elseif($row->status == 1): ?>
               <i class="far fa-check-square"></i>
               <?php elseif($row->status == 0): ?>
               <i class="fas fa-ban"></i>
               <?php endif; ?>
             </div>
             <div class="activity-detail">
              <div class="mb-2">
                <span class="text-job text-primary"><?php echo e($row->created_at->diffForHumans()); ?></span>              
              </div>
              <?php if($row->status == 3): ?>
              <p class="text-warning"><?php echo e(__('Order Accepted')); ?> </p>
              <?php elseif($row->status == 2): ?>
              <p class="text-primary"><?php echo e(__('Order Created')); ?> </p>
              <?php elseif($row->status == 1): ?>
              <p class="text-success"><?php echo e(__('Order Completed')); ?> </p>
              <?php elseif($row->status == 0): ?>
              <p class="text-danger"><?php echo e(__('Order Cancelled')); ?> </p>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <h5 class="text-primary text-center"><?php echo e(__('Rider Log')); ?></h5>
      </div>
      <div class="card-body">
        <div class="activities">
          <?php $__currentLoopData = $info->riderlog ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="activity">
            <div class="activity-icon bg-primary text-white shadow-primary">
             
             <?php if($row->status == 2): ?>
             <i class="fas fa-comment-alt"></i>
             <?php elseif($row->status == 1): ?>
             <i class="far fa-check-square"></i>
             <?php elseif($row->status == 0): ?>
             <i class="fas fa-ban"></i>
             <?php endif; ?>
           </div>
           <div class="activity-detail">
            <div class="mb-2">
              <span class="text-job text-primary"><?php echo e($row->created_at->diffForHumans()); ?></span>              
            </div>
            
            <?php if($row->status == 2): ?>
            <p class="text-warning"><?php echo e(__('Order Pending')); ?> </p>
            <?php elseif($row->status == 1): ?>
            <p class="text-success"><?php echo e(__('Order Accepted')); ?> </p>
            <?php elseif($row->status == 0): ?>
            <p class="text-danger"><?php echo e(__('Order Cancelled')); ?> </p>
            <?php endif; ?>
          </div>
          <div class="float-right dropdown">
            <a href="#" data-toggle="dropdown" aria-expanded="false"><i class="fas fa-ellipsis-h"></i></a>
            <div class="dropdown-menu" x-placement="bottom-start" >
              <div class="dropdown-title"><?php echo e(__('Rider Info')); ?></div>
              <a href="#" class="dropdown-item has-icon"><i class="far fa-id-badge"></i>ID #<?php echo e($row->user_id); ?></a>
              <a href="#" class="dropdown-item has-icon"><i class="far fa-id-badge"></i>Name: <?php echo e($row->user->name); ?></a>
              <a href="#" class="dropdown-item has-icon"><i class="fas fa-eye"></i>Order Seen <?php if($row->seen == 1): ?> <span class="badge badge-success badge-sm">Yes</span> <?php else: ?> <span class="badge badge-danger">No</span> <?php endif; ?></a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<div class="col-12 col-md-12 col-lg-5">
  <div class="card">

    <div class="card-body">

      <div class="profile-widget">

        <div class="profile-widget-header">                     

          <div class="profile-widget-items">
            <div class="profile-widget-item">
              <div class="profile-widget-item-label"><?php echo e(__('Amount')); ?></div>
              <div class="profile-widget-item-value"><?php echo e(number_format($info->total+$info->shipping,2)); ?></div>
            </div>
             <div class="profile-widget-item">
              <div class="profile-widget-item-label"><?php echo e(__('Shipping')); ?></div>
              <div class="profile-widget-item-value"><?php echo e(number_format($info->shipping,2)); ?></div>
            </div>
            <div class="profile-widget-item">
              <div class="profile-widget-item-label"><?php echo e(__('Payment Mode')); ?></div>
              <div class="profile-widget-item-value"><?php echo e(strtoupper($info->payment_method)); ?></div>
            </div>
            <div class="profile-widget-item">
              <div class="profile-widget-item-label"><?php echo e(__('Payment Status')); ?></div>
              <div class="profile-widget-item-value"><?php if($info->payment_status == 0): ?>
               <span class="text-danger"><?php echo e(__('Pending')); ?></span>
               <?php elseif($info->payment_status == 1): ?> <span class="text-success"><?php echo e(__('Completed')); ?></span> <?php endif; ?></div>

             </div>
             <div class="profile-widget-item">
              <div class="profile-widget-item-label"><?php echo e(__('Order Status')); ?></div>
              <div class="profile-widget-item-value"><?php if($info->status == 0): ?>
               <span class="text-danger"><?php echo e(__('Cancelled')); ?></span>
               <?php elseif($info->status == 2): ?> <span class="text-warning"><?php echo e(__('Pending')); ?></span> 
               <?php elseif($info->status == 3): ?> <span class="text-primary"><?php echo e(__('Accepted')); ?></span> 
               <?php elseif($info->status == 1): ?> <span class="text-success"><?php echo e(__('Completed')); ?></span> 
               <?php endif; ?>
             </div>

           </div>
         </div>
       </div>
       <?php
       $customerInfo=json_decode($info->data);

       ?>
       <div class="profile-widget-description">
        <div class="profile-widget-name"><?php echo e(__('Customer Name')); ?>: <div class="text-muted d-inline font-weight-normal"> <?php echo e($customerInfo->name); ?></div></div>
        <div class="profile-widget-name"><?php echo e(__('Customer Phone')); ?>: <div class="text-muted d-inline font-weight-normal"> <?php echo e($customerInfo->phone); ?></div></div>
        <div class="font-weight-bold mb-2"><?php echo e(__('Payment Id:')); ?> <b> <?php echo e($customerInfo->payment_id ?? ''); ?></b></div>
       
      
        <?php if($info->order_type == 1): ?>
        <div class="profile-widget-name"><?php echo e(__(' Delevery Address')); ?>: <div class="text-muted d-inline font-weight-normal"> <?php echo e($customerInfo->address); ?></div></div>
        <?php endif; ?>
        <div class="font-weight-bold mb-2"><?php echo e(__('Order Note')); ?></div>
        <?php echo e($customerInfo->note); ?>

      </div>
      
      <?php if($info->order_type == 1): ?>
     
      <div class="card-footer text-center">
        <div class="font-weight-bold mb-2"><?php echo e(__('Order Location')); ?></div>
        <div class="map_area" id="map">

        </div>
         <?php if(!empty($info->riderinfo)): ?>
        <div class="card mt-4">
          <div class="card-header text-center">
            <h4><?php echo e(__('Rider Information')); ?></h4>
          </div>
          <div class="card-body">
           <img alt="image" src="<?php echo e(asset($info->riderinfo->avatar)); ?>"  height="100"> 
            <?php if(!empty($info->riderinfo->info)): ?>
            <?php
            $data=json_decode($info->riderinfo->info->content);
            ?>
            <p><?php echo e(__('Name')); ?> : <?php echo e($info->riderinfo->name); ?></p>
            <p><?php echo e(__('Phone1')); ?> : <?php echo e($data->phone1); ?></p>
            <p><?php echo e(__('Phone2')); ?> : <?php echo e($data->phone2); ?></p>
            <p><?php echo e(__('Address')); ?> : <?php echo e($data->full_address); ?></p>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
      
      <?php endif; ?>

    </div>
  </div>
</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php if($info->order_type == 1): ?>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('PLACE_KEY')); ?>&libraries=places&sensor=false&callback=initialise"></script>
<script type="text/javascript">
  "use strict";
 var resturent_lat = <?php echo e($info->vendorinfo->location->latitude); ?>;
 var resturent_long  = <?php echo e($info->vendorinfo->location->longitude); ?>;

 var customer_lat = <?php echo e($customerInfo->latitude); ?>;
 var customer_long = <?php echo e($customerInfo->longitude); ?>;

 var resturent_icon= '<?php echo e(asset('uploads/resturent.png')); ?>';
 var user_icon= '<?php echo e(asset('uploads/userpin.png')); ?>';

 var customer_name= '<?php echo e($customerInfo->name); ?>';
 var resturent_name= '<?php echo e($info->vendorinfo->name); ?>';
 var mainUrl= "<?php echo e(url('/')); ?>";


 function initialise(){
  var map;
  var resturent = new google.maps.LatLng(resturent_lat,resturent_long);
  var customer = new google.maps.LatLng(customer_lat,customer_long);
  var option ={
    zoom : 10,
    center : resturent, 
  };
  map = new google.maps.Map(document.getElementById('map'),option);
  var display = new google.maps.DirectionsRenderer({polylineOptions: {
    strokeColor: "rgba(255, 0, 0, 0.5)"
  }});
  var services = new google.maps.DirectionsService();
  display.setMap(map);
  function calculateroute(){
    var request ={
      origin : resturent,
      destination:customer,
      travelMode: 'DRIVING'
    };
    services.route(request,function(result,status){

      if(status =='OK'){
        display.setDirections(result);
        display.setOptions( { suppressMarkers: true } );
        var leg = result.routes[ 0 ].legs[ 0 ];
        makeMarker( leg.start_location, resturent_icon, resturent_name );
        makeMarker( leg.end_location, user_icon, customer_name );
      }
    });
  }
  function makeMarker( position, icon, title ) {
   new google.maps.Marker({
    position: position,
    map: map,
    icon: icon,
    title: title
  });
 }
 calculateroute();
}


<?php endif; ?>

  //response will assign this function
   function success(res){
    $('.submit-btn').remove();
  }
</script>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.com\wwwroot\script\am-content\Themes/khana/views/admin/order/details.blade.php ENDPATH**/ ?>