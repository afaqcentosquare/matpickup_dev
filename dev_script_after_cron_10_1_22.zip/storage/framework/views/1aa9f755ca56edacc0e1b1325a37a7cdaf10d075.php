<header id="header">
    <div class="header-area <?php echo e(Request::is('store/*') ? 'header_fixed' : ''); ?>">
        <input type="hidden" id="header_close" value="<?php echo e(route('header.notify')); ?>">
        
        <?php if(!Session::has('header_notify')): ?>
        <?php if(!Request::is('store*')): ?>
        <div class="header-notify-bar">
            <div class="notify-close-btn">
                <a href="#"><span class="ti-close"></span></a>
            </div>
            <div class="notify-content text-center">
                <svg class="svg-stroke-container" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                    <path class="rider-icon__path" d="M44.66,9.09,31.19,5.18a4.66,4.66,0,0,0-2.59,0L11,10.13a4.62,4.62,0,0,0-3.37,4.36s0,0,0,.07v4C4.51,21.9.1,27.21,0,31.91A10.57,10.57,0,0,0,0,33a5,5,0,0,0,2.69,4.08,5.66,5.66,0,0,0,2.64.65,13.73,13.73,0,0,0,4.27-1,7.73,7.73,0,0,0,3.7,5.55A5.41,5.41,0,0,0,16,43a17.66,17.66,0,0,0,5.93-1.66l1.16.58a4.66,4.66,0,0,0,2.07.48,4.55,4.55,0,0,0,1.26-.17l18.16-5.91A4.62,4.62,0,0,0,48,31.87V13.51A4.64,4.64,0,0,0,44.66,9.09Zm-33.35,2,9-2.52,13.18,3.83A3.62,3.62,0,0,1,36,15.86v5L26.28,24V18.37a2.56,2.56,0,0,0-1.92-2.44L11.17,12.1a2.85,2.85,0,0,0-1.45,0A3.64,3.64,0,0,1,11.31,11.11ZM4.79,36a4,4,0,0,1-2.14-3.89c.17-2.62,2.47-5.88,5-8.82V33a2.53,2.53,0,0,0,1.52,2.29l.39.18c0,.1,0,.21,0,.32C7.84,36.31,6.09,36.61,4.79,36Zm16,4.75c-2,.66-4.14,1-5.61.37a4.89,4.89,0,0,1-3-4.48v0l4.23,2,4.58,2.13Zm2-.31-6-2.78-4.58-2.13s0-.08,0-.12c.91-4.8,6.24-12.14,9.08-15.16a1,1,0,0,0-.42-1.68l-1.21-.41a1,1,0,0,0-1.07.28c-1.78,1.95-7.92,9.28-8.92,15.48,0,.14-.06.28-.07.41l0,0A1.51,1.51,0,0,1,8.69,33V22.13c1.64-1.81,3.26-3.43,4.38-4.62a1,1,0,0,0-.43-1.68l-1.2-.41a1,1,0,0,0-1.08.28c-.36.4-.95,1-1.67,1.74v-3a1.5,1.5,0,0,1,.62-1.14A1.74,1.74,0,0,1,10.37,13a1.79,1.79,0,0,1,.51.07l13.19,3.83a1.55,1.55,0,0,1,1.17,1.46V39.08a1.48,1.48,0,0,1-.72,1.26A1.84,1.84,0,0,1,22.8,40.45ZM47,31.87a3.6,3.6,0,0,1-2.7,3.46L26.11,41.24a3.25,3.25,0,0,1-1.35.1,1.41,1.41,0,0,0,.31-.14,2.49,2.49,0,0,0,1.21-2.12v-5.5L47,27.11Zm0-14.5-9.89,3.16V15.86a4.64,4.64,0,0,0-3.34-4.42L22.12,8.06l6.76-1.91a3.77,3.77,0,0,1,1-.14,3.55,3.55,0,0,1,1,.15l13.47,3.92A3.59,3.59,0,0,1,47,13.51Z"></path>
                </svg>
                <span id="rider_team_title"><?php echo e(content('header','rider_team_title')); ?></span>
                <a href="<?php echo e(route('rider.register')); ?>" id="rider_button_title"><?php echo e(content('header','rider_button_title')); ?></a>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <div class="header-top-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="header-top-left-area">
                            <div class="header-language">

                                <?php 
                                $get_data = App\Category::where([
                                    ['type','lang'],
                                    ['status',1]
                                ])->get();
                                ?>
                                <input type="hidden" id="lang_url" value="<?php echo e(route('language.set')); ?>">
                                <select id="select_language" name="language">
                                    <?php $__currentLoopData = $get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $info = json_decode($data->content);
                                    ?>
                                    <option <?php echo e(Session::get('locale') == $data->slug ? 'selected' : ''); ?> value="<?php echo e($data->slug); ?>"><?php echo e($info->lang_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="contact-number">
                                <span class="ti-mobile"></span>
                                <span id="header_pn"><?php echo e(content('header','header_pn')); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="header-top-right-section f-right">
                            <?php if(Auth::guest()): ?>
                            <a href="<?php echo e(url('restaurant/register')); ?>"><?php echo e(__('Register Your Restaurant')); ?></a>
                            <?php endif; ?>
                            <?php if(Auth::guest()): ?>
                            <a href="<?php echo e(url('/user/login')); ?>"><span class="ti-user"></span><?php echo e(__('Login')); ?></a>
                            <?php endif; ?>
                            <?php if(Auth::check()): ?>
                            
                            <a href="<?php echo e(url('/contact')); ?>"><?php echo e(__('Contact Us')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-main-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header-logo">
                            <a href="<?php echo e(url('/')); ?>" class="pjax"><img id="logo" src="<?php echo e(asset(content('header','logo'))); ?>" alt="<?php echo e(env('APP_NAME')); ?>"></a>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="header-main-right-area">
                                <?php if(Auth::check()): ?>
                                <div class="menu_profile">
                                    <a href="#" class="f-right" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img class="profile_img" src="<?php echo e(asset(Auth::User()->avatar)); ?>"></a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a href="<?php echo e(route('author.dashboard')); ?>" class="dropdown-item"><?php echo e(__('Dashboard')); ?></a>
                                        <a href="<?php echo e(route('author.dashboard')); ?>" class="dropdown-item"><?php echo e(__('My Orders')); ?></a>
                                        <a href="<?php echo e(route('author.dashboard')); ?>" class="dropdown-item"><?php echo e(__('Settings')); ?></a>
                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();" class="dropdown-item"><?php echo e(__('Logout')); ?></a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if(Session::has('restaurant_cart')): ?>
                                <a href="<?php echo e(route('store.show',Session::get('restaurant_cart')['slug'])); ?>" class="desktop_cart_icon"><div class="shopping-cart f-right">
                                    <span class="ti-shopping-cart"></span>
                                    <?php if(Session::has('restaurant_cart')): ?>
                                    <?php if(Request::is('store/'.Session::get('restaurant_cart')['slug']) || Request::is('/') || Request::is('area*') || Request::is('checkout')): ?>
                                    <div class="count_load"><?php echo e(Cart::instance('cart_'.Session::get('restaurant_cart')['slug'])->count()); ?></div>
                                    <?php else: ?>
                                    <div class="count_load">0</div>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <div class="count_load">0</div>
                                    <?php endif; ?>
                                </div></a>
                                <a id="toggle-sidebar-left" class="mobile_cart_icon" href="#"><div class="shopping-cart f-right">
                                    <span class="ti-shopping-cart"></span>
                                    <?php if(Session::has('restaurant_cart')): ?>
                                    <?php if(Request::is('store/'.Session::get('restaurant_cart')['slug']) || Request::is('/') || Request::is('area*') || Request::is('checkout')): ?>
                                    <div class="count_load"><?php echo e(Cart::instance('cart_'.Session::get('restaurant_cart')['slug'])->count()); ?></div>
                                    <?php else: ?>
                                    <div class="count_load">0</div>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <div class="count_load">0</div>
                                    <?php endif; ?>
                                </div></a>
                                <?php else: ?>
                                <a href="#" id="toggle-sidebar-left"><div class="shopping-cart f-right">
                                    <span class="ti-shopping-cart <?php echo e(!Auth::check() ? 'mr-15' : ''); ?>"></span>
                                    <div class="count_load"></div>
                                </div></a>
                                <?php endif; ?>

                                <div class="main-menu f-right">
                                    <div class="mobile-menu">
                                        <a class="toggle f-right" href="#" role="button" aria-controls="hc-nav-1"><i class="ti-menu"></i></a>
                                    </div>
                                    <nav id="main-nav">
                                        <ul>
                                         <li></li>

                                         <?php echo e(Menu('Header','submenu','','','right',true)); ?>

                                     </ul>
                                 </nav>


                             </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <?php
 $currency=\App\Options::where('key','currency_name')->select('value')->first();
 ?>
 <div class="sidebar d-none" id="sidebar-left">
  <div class="sidebar-wrapper">
    <?php if(Session::has('restaurant_cart')): ?>
    <?php if(Session::has('cart')): ?>
    <div class="main_cart_ok">
        <div class="delivery-main-content sidebar text-center">
            <?php if(Cart::instance('cart_'.Session::get('restaurant_cart')['slug'])->count() > 0): ?>
            <?php 
            $store = App\User::where('slug',Session::get('restaurant_cart')['slug'])->with('pickup','delivery')->first();
            ?>
            <div class="delivery-toogle-action">
                <span class="delivery-title"><?php echo e(__('Delivery')); ?></span>
                <div class="custom-control custom-switch">
                    <input <?php echo e(Session::has('delivery_type') ? Session::get('delivery_type')['type'] == 0 ? 'checked' : '' : ''); ?> type="checkbox" name="delivery_type" onchange="delivery_pickup('<?php echo e($store->slug); ?>')" value="0" class="custom-control-input" id="d_p"> <label class="custom-control-label" for="d_p"><?php echo e(__('Pick Up')); ?></label>
                    <input type="hidden" id="checkout_type" value="<?php echo e(route('checkout.type')); ?>">
                </div>
            </div>
            <input type="hidden" id="pickup_price" value="<?php echo e($store->pickup->content); ?>">
            <input type="hidden" id="delivery_price" value="<?php echo e($store->delivery->content); ?>">
            <div class="delivery-avg-time" id="dummy">
                <i class="fas fa-truck"></i> <?php echo e($store->delivery->content); ?> <?php echo e(__('min')); ?>

            </div>
            <div class="delivery-order-form">
                <h5><?php echo e(__('Your order')); ?> <?php echo e($store->name); ?></h5>
            </div>
            <div class="cart-product-list">
                <?php $__currentLoopData = Cart::instance('cart_'.$store->slug)->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-cart-product d-flex">
                    <div class="cart-product-title d-block">
                        <h5><?php echo e($cart->name); ?></h5>
                        <p><?php echo e($cart->options->type); ?></p>
                    </div>
                    <div class="cart-price-action d-block">
                        <span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(number_format($cart->price,2)); ?></span>
                        <div class="cart-product-action d-flex">
                            <?php if($cart->qty > 1): ?>
                            <a href="javascript:void(0)" class="right" onclick="limit_minus('<?php echo e($cart->rowId); ?>','<?php echo e($store->slug); ?>')"><span class="ti-minus"></span></a>
                            <?php else: ?>
                            <a href="javascript:void(0)" onclick="delete_cart('<?php echo e($cart->rowId); ?>','<?php echo e($store->slug); ?>')" class="right"><span class="fas fa-trash"></span></a>
                            <?php endif; ?>
                            <div class="qty">
                                <input type="text" id="total_limit<?php echo e($cart->rowId); ?>" value="<?php echo e($cart->qty); ?>">
                            </div>
                            <a href="javascript:void(0)" class="left" onclick="limit_plus('<?php echo e($cart->rowId); ?>','<?php echo e($store->slug); ?>')"><span class="ti-plus"></span></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="cart-product-another-information">
                <div class="single-information d-flex">
                    <span><?php echo e(__('Subtotal')); ?></span>
                    <div class="main-amount">
                        <span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(Cart::subtotal()); ?></span>
                    </div>
                </div>
                <div>
                    <div class="checkout-btn">
                        <a href="<?php echo e(route('checkout.index')); ?>"><?php echo e(__('Checkout')); ?></a>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <h5 class="mt-20 mb-15"><?php echo e(__('No Item in your Cart')); ?></h5>
            <p class="mb-15"><?php echo e(__("You haven't added anything in your cart yet! Start adding the products you like.")); ?></p>
            <div class="cart-product-another-information">
                <div class="single-information d-flex">
                    <span><?php echo e(__('Subtotal')); ?></span>
                    <div class="main-amount">
                        <span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(Cart::subtotal()); ?></span>
                    </div>
                </div>
                <div class="checkout-btn disabled">
                    <a href="#" class="disabled"><?php echo e(__('Checkout')); ?></a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="main_cart_ok">
        <div class="delivery-main-content sidebar text-center">
            <h5 class="mt-20 mb-15"><?php echo e(__('No Item in your Cart')); ?></h5>
            <p class="mb-15"><?php echo e(__("You haven't added anything in your cart yet! Start adding the products you like.")); ?></p>
            <div class="cart-product-another-information">
                <div class="single-information d-flex">
                    <span><?php echo e(__('Subtotal')); ?></span>
                    <div class="main-amount">
                        <span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(Cart::subtotal()); ?></span>
                    </div>
                </div>
                <div class="checkout-btn disabled">
                    <a href="#" class="disabled"><?php echo e(__('Checkout')); ?></a>
                </div>
            </div>
        </div> 
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="main_cart_ok">
        <div class="delivery-main-content sidebar text-center">
            <h5 class="mt-20 mb-15"><?php echo e(__('No Item in your Cart')); ?></h5>
            <p class="mb-15"><?php echo e(__("You haven't added anything in your cart yet! Start adding the products you like.")); ?></p>
            <div class="cart-product-another-information">
                <div class="single-information d-flex">
                    <span><?php echo e(__('Subtotal')); ?></span>
                    <div class="main-amount">
                        <span><?php echo e(strtoupper($currency->value)); ?> <?php echo e(Cart::subtotal()); ?></span>
                    </div>
                </div>
                <div class="checkout-btn disabled">
                    <a href="#" class="disabled"><?php echo e(__('Checkout')); ?></a>
                </div>
            </div>
        </div> 
    </div>
    <?php endif; ?>
</div>
</div>
<input type="hidden" id="cart_update" value="<?php echo e(route('cart.update')); ?>">
<input type="hidden" id="cart_delete" value="<?php echo e(route('cart.delete')); ?>">
</header>




<?php /**PATH C:\xampp\htdocs\khana\script\am-content\Themes/khana/views/layouts/partials/header.blade.php ENDPATH**/ ?>