<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo e(config('app.name')); ?> | <?php echo e(Request::segment(2)); ?></title>
  <!-- Favicon icon -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('uploads/favicon.ico')); ?>">

  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.min.css')); ?>">

  <?php echo $__env->yieldContent('style'); ?>
  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/components.css')); ?>">

</head>

<body>
  <div class="loading"></div>
 <div id="app">
  <div class="main-wrapper">
    <div class="navbar-bg"></div>
    <?php echo $__env->make('layouts/backend/partials/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts/backend/partials/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Content -->
    <div class="main-content">
      <section class="section">
       <?php echo $__env->yieldContent('content'); ?>
     </section>
   </div>

   
   <footer class="main-footer">
    <div class="footer-left">
      <?php echo e(__('Copyright')); ?> &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> <?php echo e(__('Powered By')); ?> <a href="https://codecanyon.net/user/amcoders"><?php echo e(__('AMCoders')); ?></a>
    </div>
    <div class="footer-right">
    </div>
  </footer>
</div>
</div>

<?php echo $__env->yieldContent('extra'); ?>
<?php echo $__env->yieldPushContent('extra'); ?>
<!-- General JS Scripts -->
<?php if(Auth::user()->role_id == 3): ?>
<?php if(Amcoders\Plugin\Plugin::is_active('plan')): ?> {
<input id="saasurls" type="hidden" value="<?php echo e(route('store.plancheck')); ?>">
<?php endif; ?>
<?php endif; ?>
<script src="<?php echo e(asset('admin/assets/js/jquery-3.5.1.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/sweetalert2.all.min.js')); ?>"></script>

<!-- Template JS File -->
<script src="<?php echo e(asset('admin/assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<script src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
<?php if(Auth::user()->role_id == 3): ?>
<script src="<?php echo e(theme_asset('khana/public/js/saas/saas.js')); ?>"></script>
<?php endif; ?>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\files\script\resources\views/layouts/backend/app.blade.php ENDPATH**/ ?>