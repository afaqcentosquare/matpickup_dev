

<?php $__env->startSection('content'); ?>
<div class="confirm-area">
	<div class="container">
		<div class="row mt-50">
			<div class="col-lg-6 offset-lg-3">
				<div class="confirmation-page text-center">
					<i class="fas fa-check-circle"></i>
					<div class="order-confirm">
						<h4><?php echo e(__('Your Order is Confirmed')); ?></h4>
						<a href="<?php echo e(route('author.dashboard')); ?>"><?php echo e(__('View Order')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\files\script\am-content\Themes/khana/views/checkout/confirm.blade.php ENDPATH**/ ?>