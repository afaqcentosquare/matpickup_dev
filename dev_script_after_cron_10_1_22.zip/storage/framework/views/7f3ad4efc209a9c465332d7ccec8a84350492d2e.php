
<?php $__env->startPush('css'); ?>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('PLACE_KEY')); ?>&libraries=places&callback=initialize"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content mt-50">
	<div class="container">
		<div class="row">
			<div class="col-lg-10 offset-lg-1">
				<div class="register-card">
					<div class="register-progress text-center">
						<nav>
							<ul>
								<li class="active">
									<div class="register-progress-number">
										<span>1</span>
									</div>
									<div class="register-progress-body">
										<?php echo e(__('Step 1')); ?>

									</div>
								</li>
								<li class="active">
									<div class="register-progress-number">
										<span>2</span>
									</div>
									<div class="register-progress-body">
										<?php echo e(__('Step 2')); ?>

									</div>
								</li>
								<li>
									<div class="register-progress-number">
										<span>3</span>
									</div>
									<div class="register-progress-body">
										<?php echo e(__('Step 3')); ?>

									</div>
								</li>
								
							</ul>
						</nav>
					</div>

					<form action="<?php echo e(route('restaurant.register_step_2')); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<div class="register-card-body">
							<div class="row mt-30">
								<?php if(Session::has('errors')): ?>
								<div class="col-lg-12">
									<p class="alert alert-danger"><?php echo e(Session::get('errors')); ?></p>
								</div>
								<?php endif; ?>
								<div class="col-lg-12">
									<div class="form-group">
										<label><?php echo e(__('Select City')); ?></label>
										<select name="city" id="cty" class="form-control selectric">
											<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($city->id); ?>"><?php echo e($city->title); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<label><?php echo e(__('Address Line')); ?></label>
										<input  type="text" class="form-control" required="" name="address_line">
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-group">
										<label><?php echo e(__('Select Your Location')); ?></label>
										<input  type="text" class="form-control" required="" name="full_address" id="location_input" required>
									</div>
								</div>
								<input type="hidden" name="latitude" id="latitude" value="00.00">
								<input type="hidden" name="longitude" id="longitude" value="00.00">
								<div class="col-lg-12" id="map-area">
									<label><?php echo e(__('Drag Your Location')); ?></label>
									<div id="map-canvas" class="map-canvas h-300"></div>
								</div>
								<div class="col-lg-12">
									<div class="f-right">
										<button class="btn btn-danger"><?php echo e(__('Next & Save')); ?></button>
									</div>
								</div>
							</div>
						</div>
					</form>	
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script src="<?php echo e(theme_asset('khana/public/js/frontend/storeregister.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Themes/khana/views/store/register_step_2.blade.php ENDPATH**/ ?>