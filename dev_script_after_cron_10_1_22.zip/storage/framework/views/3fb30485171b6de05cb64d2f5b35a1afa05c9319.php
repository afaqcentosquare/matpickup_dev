

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-9">      
    <div class="card">
      <div class="card-body">
        <h4><?php echo e(__('Add new Plan')); ?></h4>
        <form method="post" action="<?php echo e(route('admin.plan.store')); ?>" id="basicform">
          <?php echo csrf_field(); ?>
          <div class="pt-20">
            <?php
            $arr['title']= 'Plan Name';
            $arr['id']= 'name';
            $arr['type']= 'text';
            $arr['placeholder']= 'Enter Name';
            $arr['name']= 'name';
            $arr['is_required'] = true;

            echo  input($arr);

            $arr2['title']= 'Price';
            $arr2['id']= 's_price';
            $arr2['type']= 'number';
            $arr2['placeholder']= 'Enter Price';
            $arr2['name']= 's_price';
            $arr['is_required'] = true;

            echo  input($arr2);

            $arr2['title']= 'Percentage of commission';
            $arr2['id']= 'commission';
            $arr2['type']= 'number';
            $arr2['placeholder']= 'Enter commission for per sale';
            $arr2['name']= 'commission';
            $arr['is_required'] = true;

            echo  input($arr2);
          
            $arr2['title']= 'Image Upload Limit';
            $arr2['id']= 'img_limit';
            $arr2['type']= 'number';
            $arr2['placeholder']= 'Enter Image Limit';
            $arr2['name']= 'img_limit';
            $arr['is_required'] = true;

            echo  input($arr2);
            ?>
             <div class="form-group">
              <label for="title"><?php echo e(__('Duration')); ?><span class="text-danger"><b>*</b></span></label>
              <select name="duration" class="form-control">
                <option value="month"><?php echo e(__('Monthly')); ?></option>
                <option value="year"><?php echo e(__('Yearly')); ?></option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="title"><?php echo e(__('Featured Resturent')); ?></label>
              <select name="f_resturent" class="form-control" >
                <option value="1"><?php echo e(__('Enable')); ?></option>
                <option value="0"><?php echo e(__('Disable')); ?></option>
              </select>
            </div>
           <div class="form-group">
              <label for="title"><?php echo e(__('Table Booking')); ?></label>
              <select name="table_book" class="form-control" >
                <option value="1"><?php echo e(__('Enable')); ?></option>
                <option value="0"><?php echo e(__('Disable')); ?></option>
              </select>
            </div>
          </div>

        </div>
      </div>

    </div>
    <div class="col-lg-3">
      <div class="single-area">
        <div class="card">
          <div class="card-body">
            <h5><?php echo e(__('Publish')); ?></h5>
            <hr>
            <div class="btn-publish">
              <button type="submit" class="btn btn-primary col-12"><i class="fa fa-save"></i> <?php echo e(__('Save')); ?></button>
            </div>
          </div>
        </div>
      </div>
      <div class="single-area">
        <div class="card sub">
          <div class="card-body">
            <h5><?php echo e(__('Status')); ?></h5>
            <hr>
            <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="status">
              <option selected value="1"><?php echo e(__('Published')); ?></option>
              <option value="2"><?php echo e(__('Draft')); ?></option>
            </select>
          </div>
        </div>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/am-content/Plugins/plan/views/plan/create.blade.php ENDPATH**/ ?>