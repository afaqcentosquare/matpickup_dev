

<?php $__env->startSection('content'); ?>
<div class="card"  >
	<div class="card-body">
		<div class="row mb-30">
			<div class="col-lg-6">
				<h4><?php echo e(__('Page List')); ?></h4>
			</div>
			<div class="col-lg-6">
				<div class="add-new-btn">
					<a href="<?php echo e(route('admin.page.create')); ?>" class="btn btn-primary f-right"><?php echo e(__('Add New')); ?></a>
				</div>
			</div>
		</div>
		<div class="cart-filter mb-20">
			<a href="<?php echo e(route('admin.page.index')); ?>"><?php echo e(__('All')); ?> <span>(<?php echo e(App\Terms::where('type',1)->where('status','!=',0)->count()); ?>)</span></a>
			<a href="?st=1"><?php echo e(__('Published')); ?> <span>(<?php echo e(App\Terms::where('type',1)->where('status',1)->count()); ?>)</span></a>
			<a href="?st=2"><?php echo e(__('Drafts')); ?> <span>(<?php echo e(App\Terms::where('type',1)->where('status',2)->count()); ?>)</span></a>
			<a href="?st=trash" class="trash"><?php echo e(__('Trash')); ?> <span>(<?php echo e(App\Terms::where('type',1)->where('status',0)->count()); ?>)</span></a>
		</div>
		<div class="card-action-filter">
			<form method="post" id="basicform" action="<?php echo e(route('admin.page.destroy')); ?>">
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-lg-6">
						<div class="d-flex">
							<div class="single-filter">
								<div class="form-group">
									<select class="form-control" name="status">
										<option value="publish"><?php echo e(__('Publish')); ?></option>
										<option value="trash"><?php echo e(__('Move to Trash')); ?></option>
										<option value="delete"><?php echo e(__('Delete Permanently')); ?></option>

									</select>
								</div>
							</div>
							<div class="single-filter">
								<button type="submit" class="btn btn-primary mt-1 ml-1"><?php echo e(__('Apply')); ?></button>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single-filter f-right">
							<div class="form-group">
								<input type="text" id="data_search" class="form-control" placeholder="Enter Value">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="table-responsive custom-table">
				<table class="table">
					<thead>
						<tr>
							<th class="am-select">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
									<label class="custom-control-label checkAll" for="customCheck12"></label>
								</div>
							</th>
							<th class="am-title"><?php echo e(__('Title')); ?></th>
							<th class="am-title"><?php echo e(__('Url')); ?></th>
							<th class="am-title"><?php echo e(__('Status')); ?></th>
							<th class="am-date"><?php echo e(__('Last Update')); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th>
								<div class="custom-control custom-checkbox">
									<input type="checkbox" name="ids[]" class="custom-control-input" id="customCheck<?php echo e($page->id); ?>" value="<?php echo e($page->id); ?>">
									<label class="custom-control-label" for="customCheck<?php echo e($page->id); ?>"></label>
								</div>
							</th>
							<td>
								<?php echo e($page->title); ?>

								<div class="hover">
									<a href="<?php echo e(route('admin.page.edit',$page->id)); ?>"><?php echo e(__('Edit')); ?></a>

									<a href="<?php echo e(route('admin.page.edit',$page->id)); ?>" class="last"><?php echo e(__('View')); ?></a>
								</div>
							</td>
								<td><?php echo e(url('/page',$page->slug)); ?></td>
							<td><?php if($page->status==1): ?>  <?php echo e(__('Published')); ?> <?php elseif($page->status==2): ?>  Draft <?php else: ?> <?php echo e(__('Trash')); ?> <?php endif; ?></td>
							<td><?php echo e(__('Last Modified')); ?>

								<div class="date">
									<?php echo e($page->updated_at->diffForHumans()); ?>

								</div>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</form>
				<tfoot>
					<tr>
						<th class="am-select">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input checkAll" id="customCheck12">
								<label class="custom-control-label checkAll" for="customCheck12"></label>
							</div>
						</th>
						<th class="am-title"><?php echo e(__('Title')); ?></th>
						<th class="am-title"><?php echo e(__('Url')); ?></th>
						<th class="am-title"><?php echo e(__('Status')); ?></th>
						<th class="am-date"><?php echo e(__('Last Update')); ?></th>
					</tr>
				</tfoot>
			</table>
			<?php echo e($pages->links()); ?>


		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script type="text/javascript">
	"use strict";	
	//response will assign this function
	function success(res){
		location.reload();
	}
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/admin/page/index.blade.php ENDPATH**/ ?>