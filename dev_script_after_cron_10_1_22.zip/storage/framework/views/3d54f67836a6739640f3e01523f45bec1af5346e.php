<div class="single-area">
 <div class="card sub">
  <div class="card-body">
   <h5><a href="#" data-toggle="modal" data-target=".media-single" class="text-dark"><?php echo e($title); ?></a></h5>
   <hr>
   <a href="#" data-toggle="modal" data-target=".media-single" class="single-modal">
   
    <img class="img-fluid" id="<?php echo e($preview_id); ?>" src="<?php echo e(asset($preview)); ?>"></a>
  </div>
</div>
</div>
<input type="hidden" id="<?php echo e($input_id); ?>" class="<?php echo e($input_class); ?>" name="<?php echo e($input_name); ?>" value="<?php echo e($value); ?>"><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/admin/media/section.blade.php ENDPATH**/ ?>