
<?php $__env->startSection("content"); ?>
<nav class="breadcrumb-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                
            </div>
        </div>
    </div>
</nav>

<div class="shop-product-tab section-pb">
    <div class="container">
        <div class="row mb-n7">
            <div class="col-lg-12 col-xl-12">
                
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel">
                        <div class="row grid-view g-0 shop-grid-5">
                
                            <?php if(empty($locations)): ?>
                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($store->preview->content != null): ?>
                                <!-- single slide Start -->
                            <div class="col-xl-3 col-sm-6">
                                <div class="product-card">
                                    <a class="thumb" href="<?php echo e(route("user.store.products",$store->slug)); ?>">
                                        <?php if(str_contains($store->preview->content, 'http')): ?>
                                            <img src="<?php echo e($store->preview->content); ?>" alt="" width="350px" height="235px">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset($store->preview->content)); ?>" alt="img" width="350px" height="235px"/>
                                        <?php endif; ?>
                                        
                                    </a>
                                    <div class="product-content">
                                        <h3 class="product-title">
                                            <br>
                                            <a href="<?php echo e(route("user.store.products",$store->slug)); ?>"><?php echo e($store->name); ?></a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <!-- single slide End -->
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <?php if(count($locations) > 0): ?>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($location->users->preview->content != null): ?>
                                <!-- single slide Start -->
                            <div class="col-xl-3 col-sm-6">
                                <div class="product-card">
                                    <a class="thumb" href="<?php echo e(route("user.store.products",$location->users->slug)); ?>">
                                        <?php if(str_contains($location->users->preview->content, 'http')): ?>
                                            <img src="<?php echo e($location->users->preview->content); ?>" alt="" width="350px" height="235px">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset($location->users->preview->content)); ?>" alt="img" width="350px" height="235px"/>
                                        <?php endif; ?>
                                        
                                    </a>
                                    <div class="product-content">
                                        <h3 class="product-title">
                                            <br>
                                            <a href="<?php echo e(route("user.store.products",$location->users->slug)); ?>"><?php echo e($location->users->name); ?></a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <!-- single slide End -->
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                            <?php else: ?>
                            <h1>Sorry no stores found :(<h1>
                                <br><br><br><br><br><br><br>
                            <?php endif; ?>        
                            <?php endif; ?>
                            
                           
                
                        </div>
                    </div>
                </div>
                  
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("theme::frontend.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\am-content\Themes/khana/views/frontend/stores.blade.php ENDPATH**/ ?>