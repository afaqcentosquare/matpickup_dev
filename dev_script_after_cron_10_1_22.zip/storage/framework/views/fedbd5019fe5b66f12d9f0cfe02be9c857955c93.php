
<?php $__env->startSection('content'); ?>
<div class="row">
 <div class="col-lg-9">      
  <div class="card">
   <div class="card-body">
     
    <h4>Import Multiple Products</h4>
    <form method="post" class="basicform" action="<?php echo e(route('admin.import.excel.data')); ?>" enctype="multipart/form-data">
     <?php echo csrf_field(); ?>
     <div class="custom-form pt-20">
     <select class="form-control" name="store">
      <option value="" selected>Select Store</option>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($user->resturentlocationwithcity != null): ?>
      <option value="<?php echo e($user->id); ?>"><?php echo e($user->name." ( ".$user->resturentlocationwithcity->area->title." ) "); ?></option>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
       <div class="form-group">
        <label >Select Excel File</label>
        <input type="file" name="file" class="form-control">
      </div>
     </div>
   </div>
 </div>

</div>
<div class="col-lg-3">
  <div class="single-area">
   <div class="card">
    <div class="card-body">
     <h5><?php echo e(__('Publish')); ?></h5>
     <hr>
     <div class="btn-publish">
      <button type="submit" class="btn btn-primary col-12 basicbtn"><i class="fa fa-save"></i> Upload File</button>
    </div>
  </div>
</div>
</div>

</div>
</div>


</div>


</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script>
	"use strict";	
	//success response will assign this function
	function success(res){
		location.reload();
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\morti-server\naser\matpickup.se\wwwroot\script\am-content\Plugins/product/views/admin/import_view.blade.php ENDPATH**/ ?>