
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/selectric.css')); ?>">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header">
		<h5>Create New Language</h5>
	</div>
	<div class="card-body">
		<form action="<?php echo e(route('admin.lang.store')); ?>" method="POST" id="basicform">
			<?php echo csrf_field(); ?>
			<div class="form-group">
				<label>Select Language</label>
				<select name="language_code" class="form-control select2">
					<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($row['code']); ?>"><?php echo e($row['name']); ?>  -- <?php echo e($row['nativeName']); ?> -- ( <?php echo e($row['code']); ?>)</option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label>Select Theme</label>
				<select name="theme_name" class="form-control selectric">
					<?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($theme['Text Domain']); ?>"><?php echo e($theme['Theme Name']); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
			<div class="form-group">
				<label>Select Position</label>
				<select name="theme_position" class="form-control selectric">
					<option value="LTR">LTR</option>
					<option value="RTL">RTL</option>
				</select>
			</div>
			<button type="submit" class="btn btn-primary btn-lg">Submit</button>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/js/form.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/jquery.selectric.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

<script type="text/javascript">
	"use strict";	
	//success response will assign this function
	function success(res){
		window.history.pushState('', '', '<?php echo e(route('admin.language.index')); ?>');
		location.reload();
	}
	function errosresponse(xhr){

		$("#errors").html("<li class='text-danger'>"+xhr.responseJSON[0]+"</li>")
	}
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/admin/language/create.blade.php ENDPATH**/ ?>