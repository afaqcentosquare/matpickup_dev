<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title><?php echo e(__('Verify')); ?> &mdash; <?php echo e(env('APP_NAME')); ?></title>

  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/fontawesome.min.css')); ?>">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/components.css')); ?>">
</head>

<body>
    <div class="verify-email-address">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card text-center">
                        <div class="card-header"><?php echo e(__('Verify Your Email Address')); ?></div>

                        <div class="card-body">
                            <?php if(session('resent')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                            </div>
                            <?php endif; ?>

                            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                            <?php echo e(__('If you did not receive the email')); ?>,
                            <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary p-0 m-0"><?php echo e(__('click here to request another')); ?></button>.
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>



<?php /**PATH /home/shirazas/centoshop.textiledigitizing.com/files/script/resources/views/auth/verify.blade.php ENDPATH**/ ?>