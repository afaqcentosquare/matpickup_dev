<!doctype html>
<html class="no-js" lang="<?php echo e(App::getlocale()); ?>">


<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <?php echo SEO::generate(); ?>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('uploads/favicon.ico')); ?>">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <?php if(Session::has('lang_position')): ?>
    <?php if(Session::get('lang_position') == 'RTL'): ?>
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/bootstrap-rtl.css')); ?>">
    <?php else: ?> 
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/bootstrap.min.css')); ?>">
    <?php endif; ?>
    <?php else: ?> 
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/bootstrap.min.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/fonts/themify-icons/themify-icons.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&family=Righteous&display=swap" rel="stylesheet">
    <link href="<?php echo e(theme_asset('khana/public/css/hc-offcanvas-nav.css')); ?>" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/default.css')); ?>">
    <?php
        $color = App\Options::where('key','color')->first();
        if(isset($color))
        {
            $theme_color = $color->value;
        }else{
            $theme_color = '#ff3252';
        }
    ?>
    <style>
        :root{
            --theme-color: <?php echo e($theme_color); ?>;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/responsive.css')); ?>">
    <?php if(Session::has('lang_position')): ?>
    <?php if(Session::get('lang_position') == 'RTL'): ?>
    <link rel="stylesheet" href="<?php echo e(theme_asset('khana/public/css/rtl.css')); ?>">
    <?php endif; ?>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->


    <!-- header area start -->
    <?php echo $__env->make('theme::layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header area end -->

    <div id="pjax-container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <!-- footer area start -->
    <?php echo $__env->make('theme::layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer area end -->

    <!-- JS here -->
    <script src="<?php echo e(theme_asset('khana/public/js/vendor/jquery-3.5.1.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
    <script src="<?php echo e(theme_asset('khana/public/js/store/store.js')); ?>"></script>
    <script src="<?php echo e(theme_asset('khana/public/js/store/cart.js')); ?>"></script>

    <script src="<?php echo e(theme_asset('khana/public/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(theme_asset('khana/public/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(theme_asset('khana/public/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(theme_asset('khana/public/js/hc-offcanvas-nav.js')); ?>"></script>
    <script src="<?php echo e(theme_asset('khana/public/js/simpler-sidebar.js')); ?>"></script>
    <script src="<?php echo e(theme_asset('khana/public/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\khana\script\am-content\Themes/khana/views/layouts/app.blade.php ENDPATH**/ ?>