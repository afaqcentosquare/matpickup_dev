@extends('layouts.backend.app')

@section('content')
<div class="card">
	<div class="card-body">
		
	</div>
</div>
@endsection